from datetime import datetime
from airflow import DAG
from zuka_etl.custom.operator import EtlOperator
from zuka_etl.contribution.full_flow.sql_full_flow_operator import SqlFullFlowOperatorWrapper
from zuka_etl.log import logger
from traceback import format_exc

"""
Import a iterator to spark dataframe
"""

dags = DAG(
    'sync_all_oracle_vcc',
    'database crawling',
    schedule_interval=None,
    start_date=datetime(2020, 4, 15),
    catchup=False
)

owner = ""
table = ""

t1 = SqlFullFlowOperatorWrapper(task_id="", sql_extract=f"select * from {owner}.{table}", config_task={}, dag=dags).build_etl_operator()
t1