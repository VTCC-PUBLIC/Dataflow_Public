from datetime import datetime
from airflow import DAG
from zuka_etl.custom.operator import EtlOperator
from zuka_etl.contribution.full_flow.sql_full_flow_operator import SqlFullFlowOperatorWrapper
from zuka_etl.log import logger
from traceback import format_exc
from zuka_etl.pipeline.extract.spark_utils import SparkDfFromDriver
from zuka_etl.pipeline.load.spark_utils import SparkDfToDriver

"""
Import a iterator to spark dataframe
"""

dags = DAG(
    'sync_all_oracle_vcc',
    'database crawling',
    schedule_interval=None,
    start_date=datetime(2020, 4, 15),
    catchup=False
)

t1 = EtlOperator(task_id="crawl_table_1",
                 extract=lambda _: SparkDfFromDriver.from_jdbc(table="""
                 select * from table A where created_date > '2020-04-01'
                 """),
                 transform=lambda df: df.selectExpr("max(total_conversion) as conv", "'2020-04-01' as date_key"),
                 load=lambda df: SparkDfToDriver.to_hive(
                     table="warehouse.test",
                     mode="overwrite_partition",
                     partition_by=["date_key"])
                 )
t2 = EtlOperator(task_id="crawl_table_2",
                 extract=lambda _: SparkDfFromDriver.from_jdbc(table="""
                 select * from table B where created_date > '2020-04-01'
                 """),
                 transform=lambda df: df.selectExpr("max(total_conversion) as conv", "'2020-04-01' as date_key"),
                 load=lambda df: SparkDfToDriver.to_hive(
                     table="warehouse.test_2",
                     mode="overwrite_partition",
                     partition_by=["date_key"])
                 )
t1 >> t2
