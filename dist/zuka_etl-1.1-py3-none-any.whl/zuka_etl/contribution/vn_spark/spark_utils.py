#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from zuka_etl.helpers.sql import clean_col_name
from zuka_etl.pipeline.transform.spark_utils import SparkTransCols


class SparkExtract:
    @staticmethod
    def from_csv(file_path, spark_session=None, convert_date={},

                 add_columns={},
                 cast_columns={}, transform_value={}, options_csv={}, output_query=""):
        from zuka_etl.pipeline.load.spark_utils import SparkDfToDriver
        from zuka_etl.custom.spark_hook import SparkHook
        session = spark_session if spark_session is not None else SparkHook().session
        default_option = {"delimiter": ';',
                          "header": True,
                          "encoding": "utf-8",
                          "multiLine": True}
        default_option.update(options_csv)
        df = session.read
        for k, v in default_option.items():
            df = df.option(k, v)
        df = df.csv(file_path)
        default = "dd/MM/yyyy HH:mm:ss"
        convert_date = {clean_col_name(k): v for k, v in convert_date.items()}
        select = []
        duplicate_key = {}
        for k in df.columns:
            n_col = clean_col_name(k)
            if duplicate_key.get(n_col):
                duplicate_key[n_col] += 1
            else:
                duplicate_key[n_col] = 0
            prefix = "" if duplicate_key[n_col] == 0 else str(duplicate_key[n_col])
            df = df.withColumnRenamed(k, n_col + prefix)
        for n_col in df.columns:
            if convert_date.get(n_col) is not None:
                f = convert_date.get(n_col)
                f = default if not f else f
                select.append("to_timestamp(%s,'%s') as %s" % (n_col, f, n_col))
            else:
                select.append("%s as %s" % (n_col, n_col))
        if add_columns:
            for k, v in add_columns.items():
                select.append("%s as %s" % (v, k))
        df = df.selectExpr(*select)

        if cast_columns:
            df = SparkDfToDriver.cast_columns(df, columns=cast_columns)

        if transform_value:
            SparkTransCols.trans_cols(df, transform_value=transform_value)
        if output_query:
            df.createOrReplaceTempView("temp_1")
            df = session.sql(output_query)
        return df
