from zuka_etl.custom.operator import EtlOperator
from zuka_etl.log import logger
from zuka_etl.custom.oracle_hook import OracleHook
from zuka_etl.custom.mysql_hook import MySqlHook
from zuka_etl.custom.postgre_hook import PostgresHook
from zuka_etl.pipeline.extract.spark_utils import SparkDfFromDriver
from zuka_etl.custom.spark_hook import SparkHook
from traceback import format_exc
from contextlib import closing
from pyspark.sql.functions import max
from datetime import datetime
from airflow import DAG


ETL_LOG_CONNECTION_ID = "etl_log"
TRACKING_TABLE = "database_tracking"
DATABASE_TYPE = "postgres"


def get_sql_hook(connection_id):
    if DATABASE_TYPE is "mysql":
        return MySqlHook(mysql_conn_id=connection_id)
    elif DATABASE_TYPE is "oracle":
        return OracleHook(oracle_conn_id=connection_id)
    else:
        return PostgresHook(postgres_conn_id=connection_id)


def get_database_tracking_time(database, connection_id):
    sql_get_data = f"""
        SELECT * FROM {TRACKING_TABLE} WHERE database = {database}
    """
    sql_hook = get_sql_hook(connection_id=connection_id)
    with closing(sql_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql_get_data)
            columns = [column[0] for column in cur.description]
            for r in cur:
                yield dict(zip(columns, r))


def create_syn_table(connection_id):
    if DATABASE_TYPE == "mysql":
        sql_create_table = f"""
            CREATE TABLE IF NOT EXISTS {TRACKING_TABLE} (
                id INT AUTO_INCREMENT,
                name TEXT PRIMARY KEY,
                database VARCHAR(500) NOT NULL,
                table VARCHAR(500) NOT NULL,
                updated_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )  ENGINE=INNODB;
        """
    else:
        sql_create_table = f"""
                    CREATE TABLE IF NOT EXISTS {TRACKING_TABLE} (
                        id serial,
                        name TEXT PRIMARY KEY,
                        database VARCHAR(500) NOT NULL,
                        table VARCHAR(500) NOT NULL,
                        updated_at TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """
    sql_hook = get_sql_hook(connection_id=connection_id)
    with closing(sql_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql_create_table)


def extract(extract_kwargs={}):
    if "database" in extract_kwargs:
        database = extract_kwargs["database"]
    if "connection_id" in extract_kwargs:
        connection_id = extract_kwargs["connection_id"]
    if "sql_params" in extract_kwargs:
        sql_params = extract_kwargs["sql_params"]

    # create tracking table if not exist
    create_syn_table(ETL_LOG_CONNECTION_ID)

    logger.info(f"RUN DATABASE: {database}")

    oracle_hook = OracleHook(oracle_conn_id=connection_id)
    tables_iterator = oracle_hook.get_records_dicts(
        sql="SELECT table_name FROM user_tables"
    )

    tables = list(tables_iterator)
    logger.info(tables)
    number_of_table_no_content = 0
    if len(tables) > 0:
        n = 0
        tracking_time_list = list(get_database_tracking_time(database, ETL_LOG_CONNECTION_ID))
        tracking_time_dict = {v["name"]: v for v in tracking_time_list}
        for index, table in enumerate(tables):
            try:
                table_name = table.get('TABLE_NAME')
                if table_name is not None and table_name != '':
                    n += 1
                    logger.info(n)
                    logger.info(f"processing table = {index},{table}")
                    logger.info("Count: %s" % list(oracle_hook.get_records_dicts(
                        sql=f"SELECT count(*) FROM {table_name}"
                    )))

                    name = f"{database}.{table}"
                    if "updated_time_field" in sql_params:
                        updated_time_field = sql_params["updated_time_field"]
                        sql_hook = get_sql_hook(connection_id=ETL_LOG_CONNECTION_ID)
                        description = sql_hook.get_description(f"SELECT * FROM {table_name}")
                        columns = [column[0] for column in description]
                        if updated_time_field in columns:
                            if name in tracking_time_dict:
                                updated_time_mark = str(tracking_time_dict[name]["updated_at"])
                                is_pull_all = False
                                is_write_log = True
                            else:
                                is_pull_all = True
                                is_write_log = True
                        else:
                            is_pull_all = True
                            is_write_log = False
                    else:
                        is_pull_all = True
                        is_write_log = False

                    SparkHook().run_sql(f"CREATE DATABASE IF NOT EXISTS {database}")
                    logger.info(f"start insert to table {table_name}...")
                    if is_pull_all is True:
                        sql_query = f"SELECT * FROM {table_name}"
                        df = SparkDfFromDriver.from_jdbc(table=sql_query, connection_id=connection_id)
                        new_updated_time_mark = df.agg(max(f"{updated_time_field}")).head()[0]
                        df.write.mode("overwrite").format("parquet").saveAsTable(f"{database}.{table_name}")
                        if is_write_log is True:
                            write_log(ETL_LOG_CONNECTION_ID, database, table_name, new_updated_time_mark, "insert")
                    else:
                        sql_query = f"SELECT * FROM {table_name} WHERE {updated_time_field} >= {updated_time_mark}"
                        df = SparkDfFromDriver.from_jdbc(table=sql_query, connection_id=connection_id)
                        new_updated_time_mark = df.agg(max(f"{updated_time_field}")).head()[0]
                        df.write.mode("append").format("parquet").saveAsTable(f"{database}.{table_name}")
                        write_log(ETL_LOG_CONNECTION_ID, database, table_name, new_updated_time_mark, "update")

                    logger.info('insert to table %s done' % table_name)
                    if n % 5 == 0:
                        logger.info("Stop context......")
                        SparkHook().stop()
            except Exception as e:
                logger.error(format_exc())
                SparkHook().stop()
                raise Exception("Error when get table: %s.%s" % (database, table_name))
        SparkHook().stop()
    else:
        logger.info('there is no table in coms schema ')

    logger.info('number of tables = %s' % len(tables))
    logger.info('number of tables dont have data = %s' % number_of_table_no_content)
    logger.info('insert done!!!!')


def write_log(connection_id, database, table, updated_time, type_query):
    if type_query == "insert":
        sql_query = f"""
            INSERT INTO {TRACKING_TABLE} (name, database, table, updated_at)
                VALUES ('{database}.{table}', '{database}', '{table}', '{updated_time}')
        """
    else:
        sql_query = f"""
            UPDATE {TRACKING_TABLE}
            SET updated_at = {updated_time}
            WHERE name = {database}.{table};
        """
    sql_hook = get_sql_hook(connection_id=connection_id)
    with closing(sql_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql_query)


def build_config(database, connection_id, updated_time_field=None):
    config_dict = {"database": database, "connection_id": connection_id}
    sql_params = {}
    if updated_time_field is not None:
        sql_params["updated_time_field"] = updated_time_field
    config_dict["sql_params"] = sql_params
    return config_dict


def build_etl_operator(dags, extract_kwargs):
    if dags is None:
        raise Exception("null dags exception")
    operator = EtlOperator(task_id="test_full_load", extract=extract, dag=dags,
                           extract_kwargs=extract_kwargs)
    return operator


def test():
    import sqlalchemy
    from sqlalchemy import create_engine

    engine = create_engine("mysql://linhnv52:admin@localhost:3306/test_mysql")
    sql = """
        create table if not exists test (
            test_id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=INNODB;
    """
    with closing(engine.connect()) as con:
        con.execute(sql)


def test_1():
    import sqlalchemy
    from sqlalchemy import create_engine

    engine = create_engine("mysql://linhnv52:admin@localhost:3306/test_mysql")
    with closing(engine.connect()) as con:
        rs = con.execute("DESCRIBE test")
        for row in rs:
            print(row)


def test_2():
    import sqlalchemy
    from sqlalchemy import create_engine

    engine = create_engine("mysql://linhnv52:admin@localhost:3306/test_mysql")
    with closing(engine.connect()) as con:
        rs = con.execute("SELECT * FROM test")
        for row in rs:
            for i in row:
                print(i, type(i))


dags = DAG(
    'test_full_load',
    'database crawling',
    schedule_interval=None,
    start_date=datetime(2020, 4, 12),
    catchup=False
)

# config_test = build_config("vcc_aio_raw", "oracle_aio_aiopdb_jdbc", updated_time_field="updated_date")
#
# t1 = build_etl_operator(dags, config_test)
# t1
if __name__ == "__main__":
    from zuka_etl.custom.jdbc_hook import JdbcHook
    a = JdbcHook("aaa")
    a.get_connection("a").get_extra()
    import jaydebeapi