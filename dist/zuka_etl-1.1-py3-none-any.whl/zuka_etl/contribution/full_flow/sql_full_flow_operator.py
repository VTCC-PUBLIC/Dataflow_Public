from airflow.operators.python_operator import PythonOperator
from airflow.utils.decorators import apply_defaults
from zuka_etl.pipeline.process import Process
from zuka_etl.log import logger, traceback
from zuka_etl.custom.jdbc_hook import JdbcHook
from contextlib import closing
import json
import time


class FullFlowUtils(object):

    @staticmethod
    def create_syn_table(connection_id, database_type, tracking_table):
        if database_type == "mysql":
            sql_create_table = f"""
                CREATE TABLE IF NOT EXISTS {tracking_table} (
                    task_id VARCHAR(500) PRIMARY KEY,
                    config TEXT NOT NULL,
                    updated_at INT(11) UNSIGNED NOT NULL,
                    created_at INT(11) UNSIGNED NOT NULL
                )  ENGINE=INNODB;
            """
        # else:
        #     sql_create_table = f"""
        #                 CREATE TABLE IF NOT EXISTS {tracking_table} (
        #                     id serial,
        #                     task_id TEXT PRIMARY KEY,
        #                     config TEXT NOT NULL,
        #                     updated_at TIMESTAMP NOT NULL,
        #                     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        #                 );
        #             """
        sql_hook = JdbcHook(connection_id)
        with closing(sql_hook.get_conn()) as conn:
            with closing(conn.cursor()) as cur:
                cur.execute(sql_create_table)

    @staticmethod
    def get_config_tracking(connection_id, task_id, tracking_table):
        sql_get_data = f"""
            SELECT config FROM {tracking_table} WHERE task_id = '{task_id}'
        """
        sql_hook = JdbcHook(connection_id)
        with closing(sql_hook.get_conn()) as conn:
            with closing(conn.cursor()) as cur:
                cur.execute(sql_get_data)
                columns = [column[0] for column in cur.description]
                for r in cur.fetchall():
                    yield dict(zip(columns, r))

    @staticmethod
    def write_log(connection_id, type_query, task_id, config, tracking_table):
        if type_query == "insert":
            sql_query = f"""
                INSERT INTO {tracking_table} (task_id, config, updated_at, created_at)
                    VALUES ('{task_id}', '{config}', '{str(int(time.time()))}', '{str(int(time.time()))}')
            """
        else:
            sql_query = f"""
                UPDATE {tracking_table}
                SET updated_at = now(), config = {config}
                WHERE task_id = '{task_id}';
            """
        sql_hook = JdbcHook(connection_id)
        with closing(sql_hook.get_conn()) as conn:
            with closing(conn.cursor()) as cur:
                cur.execute(sql_query)

    @staticmethod
    def write_to_local(cursor, local_path):
        with open(local_path, "w") as file:
            for row in cursor:
                file.write("|".join(row) + "\n")

    @staticmethod
    def load_to_local(value):
        pass

    @staticmethod
    def load_to_hive(value):
        pass


class SqlFullFlowOperatorWrapper(object):
    """
        example:
            dags = DAG(
                'test_full_load',
                'database crawling',
                schedule_interval=None,
                start_date=datetime(2020, 4, 12),
                catchup=False
            )

            t1 = SqlFullFlowOperatorWrapper(
                task_id="task_id_1",
                sql_extract_full="select * from table_1",
                sql_extract_condition = None,
                config_task = {},
                process_kwargs= {
                        "file_path": "/path/to/file.csv",
                        "loc_connection_id": "1234",
                        "task_connection_id": "1235"
                    },
                dag=dags
            ).build_etl_operator()
            t1
    """
    def __init__(self, task_id, sql_extract_full, sql_extract_condition, config_task, process_args=None,
                 process_kwargs=None, *args, **kwargs):
        self.task_id = task_id
        self.sql_extract_full = sql_extract_full
        self.sql_extract_condition = sql_extract_condition
        self.config_task = config_task
        self.process_args = process_args
        self.process_kwargs = process_kwargs
        self._args = args
        self._kwargs = kwargs

    def sensor(self, log_connection_id, task_connection_id):
        FullFlowUtils.create_syn_table(connection_id=log_connection_id, database_type="mysql",
                                       tracking_table="data_tracking")
        config_tracking_save = list(FullFlowUtils.get_config_tracking(connection_id=log_connection_id,
                                                                      task_id=self.task_id,
                                                                      tracking_table="data_tracking"))
        logger.info("config_tracking_save: " + str(config_tracking_save))
        file_path = self.process_kwargs["file_path"]
        task_sql_hook = JdbcHook(task_connection_id)
        if len(self.config_task) > 0:
            if len(config_tracking_save) > 0:
                # extract a part and write log
                config_tracking_save_json = json.load(config_tracking_save[0]["config"])
                for param in self.config_task:
                    if param not in config_tracking_save_json:
                        raise Exception("not invalid params in sql template")
                    sql_query = self.sql_extract_condition.replace(f"{{{param}}}", config_tracking_save_json[param])

                logger.info("sql_query: " + sql_query)
                FullFlowUtils.write_to_local(task_sql_hook.get_records(sql_query), file_path)
                config_save = {}
                for i in self.config_task:
                    config_save[i] = int(time.time())
                FullFlowUtils.write_log(log_connection_id,
                                        type_query="update",
                                        task_id=self.task_id,
                                        config=str(config_save),
                                        tracking_table="data_tracking")
            else:
                # extract full and write log
                sql_query = self.sql_extract_full
                logger.info("sql_query: " + sql_query)
                FullFlowUtils.write_to_local(task_sql_hook.get_records(sql_query), file_path)
                config_save = {}
                for i in self.config_task:
                    config_save[i] = int(time.time())
                FullFlowUtils.write_log(log_connection_id,
                                        type_query="insert",
                                        task_id=self.task_id,
                                        config=str(config_save),
                                        tracking_table="data_tracking")
        else:
            # extract full
            sql_query = self.sql_extract_full
            FullFlowUtils.write_to_local(task_sql_hook.get_records(sql_query), file_path)

    def extract(self):
        log_connection_id = self.process_kwargs["log_connection_id"]
        task_connection_id = self.process_kwargs["task_connection_id"]
        logger.info("log_connection_id: " + log_connection_id)
        logger.info("task_connection_id: " + task_connection_id)
        self.sensor(log_connection_id, task_connection_id)

    def transform(self, extract_value):
        pass

    def load(self, transform_value):
        pass

    def complete(self, load_value):
        self.kill_yarn_app()

    def kill_yarn_app(self):
        try:
            from zuka_etl.helpers.hadoop import yarn_kill_app, yarn_kill_app_by_cmd
            from zuka_etl.custom.spark_hook import SparkHook
            sp = SparkHook()
            if sp.is_active and "local" not in sp.get_master():
                logger.info("[Trigger on_kill event")
                app_id = sp.sc.applicationId
                if app_id:
                    logger.info("[Yarn] kill app by api")
                    try:
                        sp.stop()
                    except BaseException as e:
                        logger.warn("[Yarn Kill] Cannot stop spark context:\n%s", traceback.format_exc())
                        try:
                            yarn_kill_app(app_id=app_id)
                        except BaseException as e:
                            logger.warn("[Yarn Kill] error: %s " % traceback.format_exc())
                        yarn_kill_app_by_cmd(app_id=app_id)

                logger.info("[Yarn Kill] done.")
            else:
                logger.info("Skip kill yarn application because Spark is not actived")
        except BaseException as e:
            logger.warn("Error when run on_kill:\n%s" % traceback.format_exc())

    def build_pipeline(self):
        process = Process(task_id=self.task_id, extract=self.extract,
                          additional_args=None,
                          additional_kwargs=None)
        return process

    def build_etl_operator(self):
        process = self.build_pipeline()
        task = PythonOperator(python_callable=process.run, task_id=self.task_id, *self._args, **self._kwargs)
        return task
