#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

#
# Copyright Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from sqlalchemy import Column, Text
from sqlalchemy import func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, INTEGER

from zuka_etl.helpers.time_utils import current_unixtime
from zuka_etl.log import logger

Base = declarative_base()
DEFAULT_CONNECTION = "etl_metadata_connection"


class LogEtlMetadata(Base):
    __tablename__ = "etl_metadata_log"
    STATUS_SUCCESS = 1
    STATUS_FAILED = 2
    STATUS_NOT_SET = 0
    STATUS_CHANGE = 3

    id = Column(INTEGER,
                primary_key=True,
                nullable=False,
                autoincrement=True)
    task_id = Column(VARCHAR(255), nullable=False)
    dag_id = Column(VARCHAR(255), nullable=False)
    created_time = Column(INTEGER, nullable=False, default=int(current_unixtime()))
    process_time = Column(INTEGER, nullable=False, default=0)
    status = Column(INTEGER, nullable=False, default=0, comment="0: Not Set, 1: Success, 2: Failed")
    change_time = Column(INTEGER, nullable=False)
    change_time1 = Column(INTEGER, nullable=False)
    change_time2 = Column(INTEGER, nullable=False)
    change_time3 = Column(INTEGER, nullable=False)
    change_time4 = Column(INTEGER, nullable=False)
    message = Column(Text)
    engine = None

    @staticmethod
    def generate_table(engine=None, re_create=False):
        if (re_create):
            LogEtlMetadata.__table__.drop(engine)
            LogEtlMetadata.__table__.create(engine)
            logger.info("Recreate table log etl: %s success" % LogEtlMetadata.__tablename__)
        else:
            logger.info("Create table log etl: %s if not exist" % LogEtlMetadata.__tablename__)
            LogEtlMetadata.__table__.create(engine, checkfirst=True)

    def load_session(self):
        from sqlalchemy.orm import scoped_session, sessionmaker
        engine = self.engine
        if not engine:
            raise Exception("You need to load engine by method load_engine")
        return scoped_session(sessionmaker(bind=engine))

    def load_engine(self, engine=None):
        if not engine:
            from airflow.hooks.base_hook import BaseHook
            logger.info("Load metadata engine from connection: %s" % DEFAULT_CONNECTION)
            self.engine = BaseHook.get_hook(DEFAULT_CONNECTION).get_sqlalchemy_engine()
        else:
            self.engine = engine
        return self

    def find_task(self, task_id, dag_id):
        session = self.load_session()
        logger.info("Find log by task_id: %s and dag_id: %s" % (task_id, dag_id))
        rs = session.query(LogEtlMetadata).filter_by(task_id=task_id, dag_id=dag_id).first()
        if rs:
            logger.info("Log with task_id: %s and dag_id: %s exists!" % (task_id, dag_id))
            return rs
        else:
            logger.info("Cannot find and log with task_id: %s and dag_id: %s" % (task_id, dag_id))
            return None

    def get_last_checkpoint(self, task_id, dag_id, status=None):
        session = self.load_session()
        rs = session.query(
            func.max(LogEtlMetadata.change_time),
            func.max(LogEtlMetadata.change_time1),
            func.max(LogEtlMetadata.change_time2),
            func.max(LogEtlMetadata.change_time3),
            func.max(LogEtlMetadata.change_time4),
        ).filter_by(task_id=task_id, dag_id=dag_id)
        if status:
            rs = rs.filter_by(status=status)
        r = rs.first()
        rs = ("success: {0}".format(r)) if r else "failed"
        logger.info(
            "Get last change_time with task_id: %s and dag_id: %s status: %s %s!" % (
                task_id, dag_id, status, rs))
        return r if r else (0,) * 5

    def save(self, task_id, dag_id, change_time=(0, 0, 0, 0, 0), status=0, message="", process_time=0):
        cls = LogEtlMetadata().load_engine(engine=self.engine)
        session = cls.load_session()
        cur_unix = current_unixtime()
        if task_id.strip() == "" or dag_id.strip() == "":
            raise ValueError("task_id or dag_id must be set")
        if not change_time:
            change_time = (cur_unix,) * 5,

        if status not in (
                LogEtlMetadata.STATUS_NOT_SET, LogEtlMetadata.STATUS_FAILED, LogEtlMetadata.STATUS_SUCCESS):
            raise ValueError("status value: %s is invalid." % status)
        created_time = current_unixtime()
        cls.task_id = task_id
        cls.dag_id = dag_id
        cls.created_time = created_time
        cls.status = status
        cls.change_time = change_time[0]
        cls.change_time1 = change_time[1]
        cls.change_time2 = change_time[2]
        cls.change_time3 = change_time[3]
        cls.change_time4 = change_time[4]
        cls.message = message
        cls.process_time = process_time if process_time > 0 else 0
        logger.info("Save log with task_id: %s and dag_id: %s and time info: %s" % (task_id, dag_id, change_time))
        cls.generate_table(engine=cls.engine, re_create=False)
        session.add(cls)
        session.commit()
        logger.info("save success")

    def delete_by_id(self, id):
        session = self.load_session()
        model = session.query(LogEtlMetadata).filter_by(id=id).first()
        session.delete(model)
        session.commit()
        logger.info("Delete log metadata with id: %s success" % id)

    def update_status_and_message(self, id, status, message="change"):
        if status in [LogEtlMetadata.STATUS_CHANGE, LogEtlMetadata.STATUS_FAILED,
                      LogEtlMetadata.STATUS_NOT_SET, LogEtlMetadata.STATUS_SUCCESS]:
            session = self.load_session()
            model = session.query(LogEtlMetadata).filter_by(id=id).first()
            if model:
                model.message = message
                model.status = status
                session.commit()
            else:
                logger.error("Log: %s not found" % id)
        else:
            raise Exception("status: %s is invalid" % status)

    def debug(self, sql=""):
        import pandas as pd
        from zuka_etl.helpers.time_utils import convert_from_unixtime
        pd.set_option('display.max_columns', None)
        from zuka_etl.pipeline.extract.pandas_utils import PandasDfFromSQL
        df = PandasDfFromSQL.from_sql(
            ("select * from %s order by change_time desc limit 10" % self.__tablename__) if not sql else sql,
            connection_id=DEFAULT_CONNECTION
        )
        df["created_time_format"] = df.apply(lambda x: convert_from_unixtime(x["created_time"]), axis=1)
        df["change_time_format"] = df.apply(lambda x: convert_from_unixtime(x["change_time"]), axis=1)
        return df
