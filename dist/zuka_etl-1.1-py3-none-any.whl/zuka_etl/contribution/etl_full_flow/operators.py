from airflow.operators.python_operator import PythonOperator
from airflow.utils.decorators import apply_defaults

from zuka_etl.contribution.etl_full_flow.models import LogEtlMetadata
from zuka_etl.contribution.etl_full_flow.process import SQLToAnyFlowBySpark, SQLToAnyFlowByPandas, AnyToAnyFlow
from zuka_etl.custom.spark_hook import SparkHook
from zuka_etl.helpers.time_utils import convert_unixtime, current_time_local, current_unixtime, convert_from_unixtime
from zuka_etl.log import logger

class SQLToAnyOperator(PythonOperator):
    @apply_defaults
    def __init__(
            self,
            sql_extract,  # type: any,
            from_connection_id: str,
            from_spark_conf: str = None,
            spark_conf: dict = {},
            transform=None,  # type: any
            load=None,  # type: Callable,
            complete=None,  # type: Callable,
            before_run=None,
            calculate_checkpoint_func=False,
            update_checkpoint_from_field: list = ["change_time"],
            get_last_checkpoint=False,
            log_metadata_model: LogEtlMetadata = None,
            save_metadata_log=False,
            engine: str = "spark",
            start_time: int = None,
            end_time: int = None,
            sql_params: dict = {},
            additional_kwargs: dict = {},  # type: Optional[Dict]
            provide_context: bool = False,  # type: bool
            templates_dict=None,  # type: Optional[Dict]
            templates_exts=None,  # type: Optional[Iterable[str]]
            *args,
            **kwargs
    ):
        """
            Operator ETL with input is SQL Query
            Using PySpark or Pandas as execution engine with JDBC connection
            Providing options for detect changing data with storing last change time on metadata:
            
                sql_extract:List or Str. Query SQL query that used for extract data
                from_connection_id: JDBC connection for data source, defined on Airflow
                from_spark_conf: spark config that is defined on Airflow
                spark_conf: list params of SparkHook
                transform: callable or list of SparkSQL (only for engine is spark)
                load: callable. Function that will be used for saving data
                complete: callable. Function will be triggered after ETL done
                calculate_checkpoint_func: None, 'auto', callable.
                update_checkpoint_from_field: List[Str]. List fields that will be calculated max(value) to save on
                                                                 metadata.
                                                                 That will be helpful for next job
                get_last_checkpoint: bool. if True, Process will automatically get maximum change_time of
                                                       successful jobs
                log_metadata_model: metadata model (sqlachemy model) to store metadata log
                save_metadata_log: bool. if True, Process will insert lo to metadata
                engine: str. spark or pandas
                start_time: int. Unixtime
                end_time: int. Unixtime
                sql_params: dict. params that will be used for replacing variable on sql query
                additional_kwargs:
                provide_context:
                templates_dict:
                templates_exts:
                args:
                kwargs:

            Ex:
            
                define a task
               
                    t1 = SQLToAnyOperator(
                        task_id="sync_dim_stock",
                        from_connection_id="jdbc_data_source",
                        sql_extract='select * from A where created_date >= {start_time} and type = "{test}"', // start_time will be automatically calculated
                        sql_params={"test": 1},
                        load=lambda df: SparkDfToDriver.to_hive(table="test", mode=SparkDfToDriver.MODE_OVERWRITE,
                                                                        spark_df=df,
                                                                        cast_columns={
                                                                            "imported_time": "int",
                                                                        }),
                        dag=dags
                        )
        """
        super(SQLToAnyOperator, self).__init__(
            python_callable=lambda _: None,
            op_args=None,
            op_kwargs=None,
            provide_context=provide_context,
            templates_dict=templates_dict,
            templates_exts=templates_exts, *args, **kwargs)

        dag_start_unixtime = self.dag.start_date.timestamp() if self.dag.start_date else current_unixtime()
        dag_end_unixtime = self.dag.end_date.timestamp() if self.dag.end_date else convert_unixtime(
            current_time_local(end_day=True))
        dag_start_time = convert_from_unixtime(dag_start_unixtime)
        dag_end_time = convert_from_unixtime(dag_end_unixtime)
        sql_params.update({
            "dag_start_time": dag_start_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
            "dag_end_time": dag_end_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
            "dag_start_date": dag_start_time.strftime("%Y-%m-%d"),
            "dag_end_date": dag_end_time.strftime("%Y-%m-%d"),
            "dag_start_date_dim": int(dag_start_time.strftime("%Y%m%d")),
            "dag_end_date_dim": int(dag_end_time.strftime("%Y%m%d")),
            "dag_start_unixtime": dag_start_unixtime,
            "dag_end_unixtime": dag_end_unixtime
        })

        if engine == "spark":
            self.python_callable = SQLToAnyFlowBySpark(task_id=self.task_id,
                                                       dag_id=self.dag_id,
                                                       sql_extract=sql_extract,
                                                       from_connection_id=from_connection_id,
                                                       from_spark_conf=from_spark_conf,
                                                       spark_conf=spark_conf,
                                                       transform=transform,
                                                       load=load,
                                                       complete=complete,
                                                       calculate_checkpoint_func=calculate_checkpoint_func,
                                                       get_last_checkpoint=get_last_checkpoint,
                                                       save_metadata_log=save_metadata_log,
                                                       start_time=start_time,
                                                       end_time=end_time,
                                                       sql_params=sql_params,
                                                       additional_kwargs=additional_kwargs,
                                                       log_metadata_model=log_metadata_model,
                                                       update_checkpoint_from_field=update_checkpoint_from_field,
                                                       before_run=before_run
                                                       ).run
        elif engine == "pandas":
            self.python_callable = SQLToAnyFlowByPandas(task_id=self.task_id,
                                                        dag_id=self.dag_id,
                                                        sql_extract=sql_extract,
                                                        from_connection_id=from_connection_id,
                                                        transform=transform,
                                                        load=load,
                                                        complete=complete,
                                                        calculate_checkpoint_func=calculate_checkpoint_func,
                                                        get_last_checkpoint=get_last_checkpoint,
                                                        start_time=start_time,
                                                        end_time=end_time,
                                                        additional_kwargs=additional_kwargs,
                                                        log_metadata_model=log_metadata_model,
                                                        update_checkpoint_from_field=update_checkpoint_from_field,
                                                        before_run=before_run
                                                        ).run
        else:
            raise ValueError("engine: %s is invalid" % engine)

    def execute(self, context):
        super(SQLToAnyOperator, self).execute(context=context)


class AnyToAnyOperator(PythonOperator):
    @apply_defaults
    def __init__(
            self,
            extract,  # type: callable,
            transform=None,  # type: Callable
            load=None,  # type: Callable,
            complete=None,  # type: Callable,
            calculate_checkpoint_func=False,
            update_checkpoint_from_field=["change_time"],
            get_last_checkpoint=False,
            save_metadata_log=False,
            log_metadata_model=False,
            start_time=None,
            end_time=None,
            more_params={},  # type:  Optional[Dict]
            additional_kwargs={},  # type: Optional[Dict]
            provide_context=False,  # type: bool
            templates_dict=None,  # type: Optional[Dict]
            templates_exts=None,  # type: Optional[Iterable[str]]
            *args,
            **kwargs
    ):
        super(AnyToAnyOperator, self).__init__(
            python_callable=lambda _: None,
            op_args=None,
            op_kwargs=None,
            provide_context=provide_context,
            templates_dict=templates_dict,
            templates_exts=templates_exts, *args, **kwargs)
        # parsing start_date and end_date from dags

        dag_start_unixtime = self.dag.start_date.timestamp() if self.dag.start_date else current_unixtime()
        dag_end_unixtime = self.dag.end_date.timestamp() if self.dag.end_date else convert_unixtime(
            current_time_local(end_day=True))
        dag_start_time = convert_from_unixtime(dag_start_unixtime)
        dag_end_time = convert_from_unixtime(dag_end_unixtime)
        more_params.update({
            "dag_start_time": dag_start_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
            "dag_end_time": dag_end_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
            "dag_start_date": dag_start_time.strftime("%Y-%m-%d"),
            "dag_end_date": dag_end_time.strftime("%Y-%m-%d"),
            "dag_start_date_dim": int(dag_start_time.strftime("%Y%m%d")),
            "dag_end_date_dim": int(dag_end_time.strftime("%Y%m%d")),
            "dag_start_unixtime": dag_start_unixtime,
            "dag_end_unixtime": dag_end_unixtime
        })
        self.python_callable_object = AnyToAnyFlow(task_id=self.task_id,
                                                   dag_id=self.dag_id,
                                                   extract=extract,
                                                   transform=transform,
                                                   load=load,
                                                   complete=complete,
                                                   calculate_checkpoint_func=calculate_checkpoint_func,
                                                   get_last_checkpoint=get_last_checkpoint,
                                                   save_metadata_log=save_metadata_log,
                                                   start_time=start_time,
                                                   end_time=end_time,
                                                   more_params=more_params,
                                                   additional_kwargs=additional_kwargs,
                                                   log_metadata_model=log_metadata_model,
                                                   update_checkpoint_from_field=update_checkpoint_from_field
                                                   )

    def execute(self, context):
        self.python_callable_object.dag_context = context
        try:
            key_from_ct = ['ds', 'next_ds', 'prev_ds', 'ds_nodash', 'yesterday_ds', 'tomorrow_ds',
                           'end_date', 'latest_date']
            build_params = {('dag_ctx_%s' % k): context.get(k, '') for k in key_from_ct}
            execution_date = context['execution_date'].timestamp()
            next_execution_date = context['next_execution_date'].timestamp()
            build_params.update({
                'dag_ctx_execution_time': convert_from_unixtime(execution_date).strftime("%Y-%m-%d %H:%M:%S"),
                'dag_ctx_execution_date': convert_from_unixtime(execution_date).strftime("%Y-%m-%d"),
                'dag_ctx_execution_dim_date': int(convert_from_unixtime(execution_date).strftime("%Y%m%d")),
                'dag_ctx_next_execution_time': convert_from_unixtime(next_execution_date).strftime("%Y-%m-%d %H:%M:%S"),
                'dag_ctx_next_execution_date': convert_from_unixtime(next_execution_date).strftime("%Y-%m-%d"),
                'dag_ctx_next_execution_dim_date': int(convert_from_unixtime(next_execution_date).strftime("%Y%m%d"))
            })
        except BaseException as e:
            logger.error("Error when set some default values from ariflow_context: %s.\nSkip setting these values..." % e)
        self.python_callable_object.params.update(build_params)
        self.python_callable = self.python_callable_object.run
        super(AnyToAnyOperator, self).execute(context=context)
