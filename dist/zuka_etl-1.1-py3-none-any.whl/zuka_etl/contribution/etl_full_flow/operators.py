from airflow.operators.python_operator import PythonOperator
from airflow.utils.decorators import apply_defaults

from zuka_etl.contribution.etl_full_flow.process import SQLToAnyFlowBySpark, SQLToAnyFlowByPandas, AnyToAnyFlow
from zuka_etl.custom.spark_hook import SparkHook
from zuka_etl.contribution.etl_full_flow.models import LogEtlMetadata


class SQLToAnyOperator(PythonOperator):
    @apply_defaults
    def __init__(
            self,
            sql_extract,  # type: any,
            from_connection_id: str,
            from_spark_conf: str = None,
            transform=None,  # type: any
            load=None,  # type: Callable,
            complete=None,  # type: Callable,
            prepare_change_time_func=False,
            update_change_time_from_field: list = ["change_time"],
            auto_calculate_last_time=False,
            log_metadata_model: LogEtlMetadata = None,
            save_metadata_log=False,
            engine: str = "spark",
            start_time: int = None,
            end_time: int = None,
            sql_params: dict = {},
            additional_kwargs: dict = {},  # type: Optional[Dict]
            provide_context: bool = False,  # type: bool
            templates_dict=None,  # type: Optional[Dict]
            templates_exts=None,  # type: Optional[Iterable[str]]
            *args,
            **kwargs
    ):
        """
        Operator ETL with input is SQL Query
        Using PySpark or Pandas as execution engine with JDBC connection
        Providing options for detect changing data with storing last change time on metadata
            :param sql_extract:List or Str. Query SQL query that used for extract data
            :param from_connection_id: JDBC connection for data source, defined on Airflow
            :param from_spark_conf: spark config that is defined on Airflow
            :param transform: callable or list of SparkSQL (only for engine is spark)
            :param load: callable. Function that will be used for saving data
            :param complete: callable. Function will be triggered after ETL done
            :param prepare_change_time_func: None, 'auto', callable.
            :param update_change_time_from_field: List[Str]. List fields that will be calculated max(value) to save on
                                                             metadata.
                                                             That will be helpful for next job
            :param auto_calculate_last_time: bool. if True, Process will automatically get maximum change_time of
                                                   successful jobs
            :param log_metadata_model: metadata model (sqlachemy model) to store metadata log
            :param save_metadata_log: bool. if True, Process will insert lo to metadata
            :param engine: str. spark or pandas
            :param start_time: int. Unixtime
            :param end_time: int. Unixtime
            :param sql_params: dict. params that will be used for replacing variable on sql query
            :param additional_kwargs:
            :param provide_context:
            :param templates_dict:
            :param templates_exts:
            :param args:
            :param kwargs:
        Ex:
        define a task
        t1 = SQLToAnyOperator(
            task_id="sync_dim_stock",
            from_connection_id="jdbc_data_source",
            sql_extract='select * from A where created_date >= {start_time} and type = "{test}"', // start_time will be automatically calculated
            sql_params={"test": 1},
            load=lambda df: SparkDfToDriver.to_hive(table="test", mode=SparkDfToDriver.MODE_OVERWRITE,
                                                            spark_df=df,
                                                            cast_columns={
                                                                "imported_time": "int",
                                                            }),
            dag=dags
            )
        """
        super(SQLToAnyOperator, self).__init__(
            python_callable=lambda _: None,
            op_args=None,
            op_kwargs=None,
            provide_context=provide_context,
            templates_dict=templates_dict,
            templates_exts=templates_exts, *args, **kwargs)
        if engine == "spark":
            self.python_callable = SQLToAnyFlowBySpark(task_id=self.task_id,
                                                       dag_id=self.dag_id,
                                                       sql_extract=sql_extract,
                                                       from_connection_id=from_connection_id,
                                                       from_spark_conf=from_spark_conf,
                                                       transform=transform,
                                                       load=load,
                                                       complete=complete,
                                                       prepare_change_time_func=prepare_change_time_func,
                                                       auto_calculate_last_time=auto_calculate_last_time,
                                                       save_metadata_log=save_metadata_log,
                                                       start_time=start_time,
                                                       end_time=end_time,
                                                       sql_params=sql_params,
                                                       additional_kwargs=additional_kwargs,
                                                       log_metadata_model=log_metadata_model,
                                                       update_change_time_from_field=update_change_time_from_field
                                                       ).run
        elif engine == "pandas":
            self.python_callable = SQLToAnyFlowByPandas(task_id=self.task_id,
                                                        dag_id=self.dag_id,
                                                        sql_extract=sql_extract,
                                                        from_connection_id=from_connection_id,
                                                        transform=transform,
                                                        load=load,
                                                        complete=complete,
                                                        prepare_change_time_func=prepare_change_time_func,
                                                        auto_calculate_last_time=auto_calculate_last_time,
                                                        start_time=start_time,
                                                        end_time=end_time,
                                                        additional_kwargs=additional_kwargs,
                                                        log_metadata_model=log_metadata_model,
                                                        update_change_time_from_field=update_change_time_from_field
                                                        ).run
        else:
            raise ValueError("engine: %s is invalid" % engine)

    def execute(self, context):
        super(SQLToAnyOperator, self).execute(context=context)
        SparkHook.kill_yarn_app()


class AnyToAnyOperator(PythonOperator):
    @apply_defaults
    def __init__(
            self,
            extract,  # type: callable,
            transform=None,  # type: Callable
            load=None,  # type: Callable,
            complete=None,  # type: Callable,
            prepare_change_time_func=False,
            update_change_time_from_field=["change_time"],
            auto_calculate_last_time=False,
            save_metadata_log=False,
            log_metadata_model=False,
            start_time=None,
            end_time=None,
            more_params={},  # type:  Optional[Dict]
            additional_kwargs={},  # type: Optional[Dict]
            provide_context=False,  # type: bool
            templates_dict=None,  # type: Optional[Dict]
            templates_exts=None,  # type: Optional[Iterable[str]]
            *args,
            **kwargs
    ):
        super(AnyToAnyOperator, self).__init__(
            python_callable=lambda _: None,
            op_args=None,
            op_kwargs=None,
            provide_context=provide_context,
            templates_dict=templates_dict,
            templates_exts=templates_exts, *args, **kwargs)

        self.python_callable = AnyToAnyFlow(task_id=self.task_id,
                                            dag_id=self.dag_id,
                                            extract=extract,
                                            transform=transform,
                                            load=load,
                                            complete=complete,
                                            prepare_change_time_func=prepare_change_time_func,
                                            auto_calculate_last_time=auto_calculate_last_time,
                                            save_metadata_log=save_metadata_log,
                                            start_time=start_time,
                                            end_time=end_time,
                                            more_params=more_params,
                                            additional_kwargs=additional_kwargs,
                                            log_metadata_model=log_metadata_model,
                                            update_change_time_from_field=update_change_time_from_field
                                            ).run

    def execute(self, context):
        super(AnyToAnyOperator, self).execute(context=context)
        SparkHook.kill_yarn_app()
