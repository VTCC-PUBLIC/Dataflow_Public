#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

import copy
import time
import traceback

from zuka_etl.contribution.etl_full_flow.models import LogEtlMetadata
from zuka_etl.custom.spark_hook import SparkHook
from zuka_etl.helpers.sql import replace_template
from zuka_etl.helpers.time_utils import current_unixtime, convert_date_to_dim_date, convert_from_unixtime, \
    current_time_local, convert_unixtime, convert_time, convert_int
from zuka_etl.log import logger
#
# Copyright Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from zuka_etl.pipeline.process import Process


class FullFlowProcess(Process):

    def __init__(self, task_id, dag_id, extract, transform=None, load=None, complete=None,
                 get_last_checkpoint="auto",
                 calculate_checkpoint_func="auto",
                 additional_args=None,
                 additional_kwargs=None,
                 more_params={},
                 log_metadata_model="auto",
                 save_metadata_log=True,
                 start_time=None,
                 end_time=None,
                 before_run=None,
                 **kwargs
                 ):
        """
        Execute Full ETL process with writing check_point log to metadata

        Parameters

            task_id:
            dag_id:
            extract:
            transform:
            load:
            complete:
            get_last_checkpoint:
            calculate_checkpoint_func: 'auto', False, Func
            additional_args:
            additional_kwargs:
            more_params:
            log_metadata_model:
            save_metadata_log:
            start_time: unixtime
            end_time: unixtime
            kwargs:

        """
        self.task_id = task_id
        self.dag_id = dag_id
        self.extract_func = extract
        self.transform_func = transform
        self.load_func = load
        self.shipper = {}
        self.complete_func = complete
        self.additional_args = copy.copy(additional_args or {})
        self.additional_kwargs = copy.copy(additional_kwargs or {})
        self.more_params = copy.copy(more_params or {})
        self.params = {}

        if log_metadata_model == "auto":
            self.log_model = LogEtlMetadata().load_engine()
        elif log_metadata_model and not isinstance(log_metadata_model, LogEtlMetadata):
            raise ValueError("log_metadata_model must be instance of LogEtlMetadata")
        else:
            self.log_model = None

        self.end_time = end_time
        self.start_time, self.start_time1, self.start_time2, self.start_time3, self.start_time4 = (start_time,) * 5
        self.get_last_checkpoint = get_last_checkpoint
        self.save_metadata_log = save_metadata_log
        self.calculate_checkpoint_func = calculate_checkpoint_func
        self.before_run = before_run

    def calculate_last_checkpoint(self):
        if callable(self.get_last_checkpoint):
            logger.info("Run custom get_last_checkpoint function to calculate last checkpoint...")
            self.get_last_checkpoint(self)
            return self
        if isinstance(self.log_model, LogEtlMetadata) and self.get_last_checkpoint:
            logger.info("Get last_checkpoint of previous job on log metadata table")
            self.start_time, self.start_time1, self.start_time2, self.start_time3, self.start_time4 = self.log_model.get_last_checkpoint(
                task_id=self.task_id, dag_id=self.dag_id,
                status=LogEtlMetadata.STATUS_SUCCESS)
            if self.start_time is None:
                logger.info("Cannot get last_checkpoint of previous job, set current day as start_time")
                self.start_time, self.start_time1, self.start_time2, self.start_time3, self.start_time4 = (
                        (convert_unixtime(date_time=current_time_local(reset_time=True)),) * 5)

            if not self.end_time:
                self.end_time = convert_unixtime(convert_time(current_time_local(end_day=True)))
        return self

    def prepare_params(self):

        self.start_time = convert_unixtime(
            current_time_local(reset_time=True)) if not self.start_time else self.start_time
        self.start_time1 = convert_unixtime(
            current_time_local(reset_time=True)) if not self.start_time1 else self.start_time1
        self.start_time2 = convert_unixtime(
            current_time_local(reset_time=True)) if not self.start_time2 else self.start_time2
        self.start_time3 = convert_unixtime(
            current_time_local(reset_time=True)) if not self.start_time3 else self.start_time3
        self.start_time4 = convert_unixtime(
            current_time_local(reset_time=True)) if not self.start_time4 else self.start_time4

        self.end_time = convert_unixtime(
            current_time_local(end_day=True)) if not self.end_time else self.end_time

        end_date = convert_from_unixtime(self.end_time)
        start_time, start_time1, start_time2, start_time3, start_time4 = convert_from_unixtime(
            self.start_time), convert_from_unixtime(self.start_time1), convert_from_unixtime(
            self.start_time2), convert_from_unixtime(self.start_time3), convert_from_unixtime(self.start_time4)
        default = {
            "start_time": self.start_time,
            "start_time1": self.start_time1,
            "start_time2": self.start_time2,
            "start_time3": self.start_time3,
            "start_time4": self.start_time4,
            "start_date": start_time.strftime("%Y-%m-%d"),
            "start_date1": start_time1.strftime("%Y-%m-%d"),
            "start_date2": start_time2.strftime("%Y-%m-%d"),
            "start_date3": start_time3.strftime("%Y-%m-%d"),
            "start_date4": start_time4.strftime("%Y-%m-%d"),
            "start_datetime": start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "start_datetime1": start_time1.strftime("%Y-%m-%d %H:%M:%S"),
            "start_datetime2": start_time2.strftime("%Y-%m-%d %H:%M:%S"),
            "start_datetime3": start_time3.strftime("%Y-%m-%d %H:%M:%S"),
            "start_datetime4": start_time4.strftime("%Y-%m-%d %H:%M:%S"),
            "start_time_object": start_time,
            "start_time_object1": start_time1,
            "start_time_object2": start_time2,
            "start_time_object3": start_time3,
            "start_time_object4": start_time4,
            "start_dim_date": convert_date_to_dim_date(start_time),
            "start_dim_date1": convert_date_to_dim_date(start_time1),
            "start_dim_date2": convert_date_to_dim_date(start_time2),
            "start_dim_date3": convert_date_to_dim_date(start_time3),
            "start_dim_date4": convert_date_to_dim_date(start_time4),

            "check_point_will_be_update": self.end_time,
            "check_point_will_be_update1": self.end_time,
            "check_point_will_be_update2": self.end_time,
            "check_point_will_be_update3": self.end_time,
            "check_point_will_be_update4": self.end_time,

            "end_time": self.end_time,
            "end_date": end_date.strftime("%Y-%m-%d"),
            "end_time_object": end_date,
            "end_dim_date": convert_date_to_dim_date(end_date),

        }
        self.params.update(default)
        self.params.update(self.more_params)
        return self

    def run(self, *args, **kwargs):
        self.calculate_last_checkpoint()
        self.prepare_params()
        if self.get_last_checkpoint:
            logger.info("Time metadata info: \n%s" % self.params)
        st = time.time()

        if not self.log_model or not self.save_metadata_log:
            if callable(self.before_run):
                logger.info("Execute function before_run before run process...")
                self.before_run(self)
            logger.info("Skip insert log to metadata because log_mode is not set or save_metadata_log option is True")
            return super(FullFlowProcess, self).run()
        try:
            if callable(self.before_run):
                logger.info("Execute function before_run before run process...")
                self.before_run(self)
            super(FullFlowProcess, self).run()
            self.log_model.save(
                task_id=self.task_id,
                dag_id=self.dag_id,
                change_time=(self.params.get("check_point_will_be_update"),
                             self.params.get("check_point_will_be_update1"),
                             self.params.get("check_point_will_be_update2"),
                             self.params.get("check_point_will_be_update3"),
                             self.params.get("check_point_will_be_update4")
                             ),
                status=LogEtlMetadata.STATUS_SUCCESS,
                process_time=time.time() - st,
                message="success"
            )
        except BaseException as e:
            self.log_model.save(
                task_id=self.task_id,
                dag_id=self.dag_id,
                change_time=(self.params.get("check_point_will_be_update"),
                             self.params.get("check_point_will_be_update1"),
                             self.params.get("check_point_will_be_update2"),
                             self.params.get("check_point_will_be_update3"),
                             self.params.get("check_point_will_be_update4")
                             ),
                status=LogEtlMetadata.STATUS_FAILED,
                process_time=int(time.time() - st),
                message=traceback.format_exc()
            )
            raise Exception(e)

    def prepare_checkpoint_to_save(self, trans_value, load_value):
        return current_unixtime()

    def complete(self, trans_value, load_value):
        if self.calculate_checkpoint_func is not False:
            rs = current_unixtime()
            if callable(self.calculate_checkpoint_func):
                logger.info("Calculate check_point to store on metadata table ")
                rs = self.calculate_checkpoint_func(self, trans_value, load_value)
            elif self.calculate_checkpoint_func == "auto":
                logger.info("Using default function prepare_check_point_func to store check_point to metadata log")
                rs = self.prepare_checkpoint_to_save(trans_value, load_value)

            if isinstance(rs, tuple) or isinstance(rs, list):
                if len(rs) == 0:
                    rs = [self.start_time] * 5
                else:
                    rs = list(rs[:5]) + [rs[0]] * (5 - len(rs))
            else:
                rs = [rs] * 5

            for i, x in enumerate(rs):
                self.params["change_date_will_be_update%s" % (i if i > 0 else "")] = convert_date_to_dim_date(
                    convert_from_unixtime(x))
                self.params["check_point_will_be_update%s" % (i if i > 0 else "")] = x
            logger.info(
                "After calculate automatically, check_point_will_be_update: %s" %
                (self.params["check_point_will_be_update"]))
        return super(FullFlowProcess, self).complete(trans_value, load_value)


class SQLToAnyFlowBySpark(FullFlowProcess):
    """
    SQL ETL Flow by Spark
    """

    def __init__(self, task_id, dag_id, sql_extract,
                 from_connection_id,
                 from_spark_conf="",
                 spark_conf: dict = {},
                 sql_params={},
                 transform=None,
                 load=None,
                 complete=None,
                 calculate_checkpoint_func=False,
                 additional_args=None,
                 additional_kwargs=None,
                 get_last_checkpoint=False,
                 log_metadata_model=None,
                 save_metadata_log=False,
                 start_time=None,
                 end_time=None,
                 before_run=None,
                 **kwargs
                 ):
        """
        Execute ETL flow by SparkSQL

        Parameters
        
            task_id:
            dag_id:
            sql_extract: list or sql query string
            from_connection_id:
            from_spark_conf:
            spark_conf: list params of SparkHook
            sql_params:
            transform: func or list query string
            load: func or list query string
            complete:
            calculate_checkpoint_func:
            additional_args:
            additional_kwargs:
            get_last_checkpoint:
            log_metadata_model:
            save_metadata_log:
            start_time:
            end_time:
            kwargs:

        """
        self.sql_extract = sql_extract
        self.from_connection_id = from_connection_id
        self.calculate_checkpoint_func = calculate_checkpoint_func
        self.spark_hook = SparkHook(connection_id=from_spark_conf, **spark_conf)
        self.update_checkpoint_from_field = kwargs.get("update_checkpoint_from_field", ["check_point"])
        self.update_checkpoint_from_field = [self.update_checkpoint_from_field] if not isinstance(
            self.update_checkpoint_from_field, list) else self.update_checkpoint_from_field
        super(SQLToAnyFlowBySpark, self).__init__(task_id=task_id,
                                                  dag_id=dag_id,
                                                  extract=None,
                                                  transform=transform,
                                                  load=load,
                                                  complete=complete,
                                                  get_last_checkpoint=get_last_checkpoint,
                                                  calculate_checkpoint_func=calculate_checkpoint_func,
                                                  additional_args=additional_args,
                                                  additional_kwargs=additional_kwargs,
                                                  log_metadata_model=log_metadata_model,
                                                  save_metadata_log=save_metadata_log,
                                                  more_params=sql_params,
                                                  start_time=start_time,
                                                  end_time=end_time,
                                                  before_run=before_run
                                                  )

    def extract(self):
        from zuka_etl.pipeline.extract.spark_utils import SparkDfFromDriver
        sql_extract = self.sql_extract if isinstance(self.sql_extract, list) else [self.sql_extract]
        list_df = []
        for index, sql in enumerate(sql_extract):
            sql = replace_template(sql, self.params)
            logger.info("[Extract] SQL query will be used for extracting: %s" % sql)
            df = SparkDfFromDriver.from_jdbc(table=sql,
                                             spark_session=self.spark_hook.session,
                                             connection_id=self.from_connection_id)
            logger.info("[Extract] Create temp view with name: TABLE_TEMP_%s" % index)
            df.createOrReplaceTempView("TABLE_TEMP_%s" % index)
            list_df.append(df)
        return list_df if isinstance(self.sql_extract, list) else list_df[0]

    def transform(self, extract_value):
        if isinstance(self.transform_func, list):
            logger.info("[Transform] Run Transform by SparkSQL String")
            r = None
            for sql in self.transform_func:
                sql = replace_template(sql, self.params)
                r = self.spark_hook.run_sql(sql=sql)
            return r
        else:
            return super(SQLToAnyFlowBySpark, self).transform(extract_value)

    def load(self, transform_value):
        if isinstance(self.load_func, list):
            logger.info("[Load] Run Load by SparkSQL String")
            r = None
            for sql in self.load_func:
                sql = replace_template(sql, self.params)
                r = self.spark_hook.run_sql(sql=sql)
            return r
        else:
            return super(SQLToAnyFlowBySpark, self).load(transform_value)

    def prepare_checkpoint_to_save(self, trans_value, load_value):
        if self.update_checkpoint_from_field:
            if isinstance(trans_value, list):
                trans_value = trans_value[-1] if len(trans_value) > 0 else None
            if trans_value.take(1):
                col = []
                for i, k in enumerate(self.update_checkpoint_from_field):
                    if k not in trans_value.columns:
                        raise ValueError("Your Dataframe has not field: %s" % k)
                    col.append("cast(max(%s) as int) as max_time%s" % (k, (i if i > 0 else "")))
                rs = trans_value.selectExpr(*col).first()
                if rs:
                    re = []
                    for r in rs:
                        try:
                            r = convert_int(r)
                            convert_from_unixtime(r)
                        except BaseException as e:
                            raise ValueError(
                                "Your calculate check_point is invalid: %s, please use unixtime format" % r)
                        re.append(r)
                    logger.info("calculate check_point to save for this job is: %s" % re)
                    return re
            else:
                logger.info("calculate check_point skip because result of transform function is empty")
                return 1
        else:
            logger.info("calculate check_point skip because update_check_point_from_field is empty")
            sync = self.params.get("check_point", 1)
            return sync

        raise ValueError("Cannot calculate check_point for saving into log metadata")


class SQLToAnyFlowByPandas(SQLToAnyFlowBySpark):
    """
        SQL ETL Flow by pandas
    """

    def extract(self):
        from zuka_etl.pipeline.extract.pandas_utils import PandasDfFromSQL
        sql = replace_template(self.sql_extract, self.params)
        logger.info("SQL query will be used for extracting: %s" % sql)
        df = PandasDfFromSQL.from_sql(table=sql, connection_id=self.from_connection_id, **self.additional_kwargs)
        return df

    def prepare_checkpoint_to_save(self, trans_value, load_value):
        if not trans_value.empty and self.update_checkpoint_from_field:
            rs = []
            for i, k in enumerate(self.update_checkpoint_from_field):
                if k not in trans_value.columns:
                    raise ValueError("Your Dataframe has not field: %s" % k)
                rs.append(trans_value[k].max())
            if rs:
                logger.info("calculate check_point to save for this job is: %s" % rs)
                re = []
                for r in rs:
                    try:
                        convert_from_unixtime(r)
                    except BaseException as e:
                        logger.error(traceback.format_exc())
                        raise ValueError("Your calculate check_point is invalid: %s, please use unixtime format" % r)
                    re.append(r)
                return re
        else:
            logger.info("calculate check_point skip because result of transform function is empty")
            sync = self.params.get("check_point", current_unixtime())
            return sync

        raise ValueError("Cannot calculate check_point for saving into log metadata")


class AnyToAnyFlow(FullFlowProcess):
    """
        Any To Any ETL Flow
    """

    def extract(self):
        return super(FullFlowProcess, self).extract()

    def prepare_checkpoint_to_save(self, trans_value, load_value):
        return current_unixtime()
