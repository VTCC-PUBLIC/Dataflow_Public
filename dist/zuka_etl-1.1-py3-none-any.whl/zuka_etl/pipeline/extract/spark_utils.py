#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

import pandas as pd
import pyspark.sql.types as types
from airflow.hooks.base_hook import BaseHook
from airflow.hooks.jdbc_hook import JdbcHook
from pyspark.sql.types import StructField, StructType

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
from zuka_etl.log import logger
from zuka_etl.utils import generate_batches
from zuka_etl.utils import timeit


class SparkDfFromDriver(object):
    """
        Using driver that setup by JAR and Spark Session
   
    """

    @staticmethod
    def cast_columns(df, columns={}, lowercase_columns=True):
        """
                :param df:
                :param columns:
                :param lowercase_columns:
                :return:
        """
        cols = df.columns
        columns = {k.lower(): v.lower() for k, v in columns.items()}
        select = []
        for k in cols:
            l_k = k.lower()
            if columns.get(l_k):
                v = columns.get(l_k)
                select.append("CAST(`%s` as %s) as %s" % (k, v, l_k if lowercase_columns else k))
            else:
                select.append("`%s` as %s" % (k, l_k if lowercase_columns else k))
        logger.info("Columns will be casted: %s" % columns)
        return df.selectExpr(*select)

    @staticmethod
    def from_jdbc(table: str, connection_id: str, spark_session=None,
                  auto_cast_field_id: bool = False,
                  lowercase_columns: bool = True,
                  cast_columns: dict = {}, options: dict = {}, **kwargs):
        """
         create a dataframe with jdbc config
         
             params:
                    table: table or sql query: ex: (select * from a) s . You need to pass an 
                        alias like example
                    connection_id: defined from admin-connection airflow
                    kwargs:
                        params: param to replace on query. ex: select * from {table}, params will be: 
                        {'table': 'database.test_table'}
                    return:
            
        """
        from zuka_etl.custom.spark_hook import SparkHook
        config = JdbcHook.get_connection(connection_id)
        session = spark_session if spark_session is not None else SparkHook().session
        table = table.strip().rstrip(';')
        if table.strip()[:1] != '(':
            table = '(%s) s' % table

        df_load = (session.read.format("jdbc").option("url",
                                                      config.host)
                   .option("dbtable", table))
        if config.login:
            df_load = df_load.option("user", config.login)
        if config.password:
            df_load = df_load.option("password", config.password)
        df_load = df_load.option("driver", config.extra_dejson.get("extra__jdbc__drv_clsname")) \
            .option("isolationLevel", "READ_UNCOMMITTED")
        if isinstance(options, dict) and options:
            for k, v in options.items():
                df_load = df_load.option(k, v)
        df = df_load.load()
        if auto_cast_field_id:
            col = df.columns
            sel = []
            for k in col:
                k_l = k.lower()
                if k_l == "id" or k_l.startswith("id_") or k_l.endswith("_id"):
                    sel.append("CAST(%s as bigint) as %s" % (k, k))
                else:
                    sel.append(k)
            return df.selectExpr(*sel)
        return SparkDfFromDriver.cast_columns(df, cast_columns, lowercase_columns)

    @staticmethod
    def from_elastic(index, query_string, connection_id, lowercase_columns=True,
                     cast_columns={}, **kwargs):
        """
         Create a dataframe from elastichsearch

                index: elastichsearch index
                query q:  query string: q=dim_date:[1543536000 TO 1543536000] 
                    AND item_type:DEAL
                elastich_config: elastichsearch config name (you can find this name on 
                    Setting of project in DATA_SOURCE params to replace on query. 
                    ex: q=field_a:[{start} TO {stop}], params will be: {'start': 1111111,'stop': 1222222}
                return: pyspark.sql.dataframe.DataFrame
        
         """
        from zuka_etl.custom.spark_hook import SparkHook
        config = BaseHook.get_connection(connection_id)
        table = SparkHook.replace_template(text=index, params=kwargs.get('params', {}))
        qr = '%s?q=%s' % (table, query_string)
        logger.info(
            '[Spark] create dataframe with elastichsearch host: %s\nSource: \n%s\nFull query: %s\n' % (
                config.host, index, qr))

        ct = SparkHook().sql_context.read.format("org.elasticsearch.spark.sql")
        cf = {
            "es.nodes": config.host,
            "es.port": config.port
        }
        if kwargs.get('select', ''):
            cf.update({
                'es.read.field.include': kwargs.get('select', '')
            })
        cf.update(kwargs.get('config', {}))
        cf.update(config.get('option', {}))
        for k, v in cf.items():
            logger.info("set conifg elastic: %s:%s" % (k, v))
            ct = ct.option(k, v)
        df = ct.load(qr)
        return SparkDfFromDriver.cast_columns(df, cast_columns, lowercase_columns)

    @staticmethod
    def from_csv(file_path: str, spark_session=None,
                 is_clean_cols_name: bool = True,
                 lowercase_columns: bool = True,
                 cast_columns: dict = {}, transform_value: dict = {}, options_csv: dict = {}, output_query: str = ""):
        """
        Import CSV file as Spark DataFrame
        Parameter:
            :param file_path: file path that will be imported
            :param spark_session:
            :param is_clean_cols_name: clean column name of csv file. Ex: "Total Number -> total_number"
            :param cast_columns: convert data type of column. Ex: {"number": "int"}
            :param transform_value: transform data of column. Ex: "number": "cast(number as int) as number"
            :param options_csv: Options for Spark read csv
            :param output_query: If this param is set. Dataframe will be registered as table: temp_1 and you can pass query to get data from table: temp_1.
                                 Ex: "select * from temp_1 where number > 1"
        :return:
        """
        from zuka_etl.pipeline.load.spark_utils import SparkDfToDriver
        from zuka_etl.custom.spark_hook import SparkHook
        from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
        from zuka_etl.helpers.sql import clean_col_name
        session = spark_session if spark_session is not None else SparkHook().session
        default_option = {"delimiter": ';',
                          "header": True,
                          "encoding": "utf-8",
                          "escape": '"',
                          "multiLine": True}
        default_option.update(options_csv)
        df = session.read
        for k, v in default_option.items():
            df = df.option(k, v)
        df = df.csv(file_path)
        if is_clean_cols_name:
            for k in df.columns:
                n_col = clean_col_name(k)
                df = df.withColumnRenamed(k, n_col)
        if cast_columns or lowercase_columns:
            df = SparkDfToDriver.cast_columns(df, columns=cast_columns, lowercase_columns=lowercase_columns)
        if transform_value:
            df = SparkTransCols.trans_cols(df, transform_value=transform_value)
        if output_query:
            df.createOrReplaceTempView("temp_1")
            df = session.sql(output_query)
        return df


class SparkDfFromIterator(object):
    DEFAULT_BATCH_SIZE = 100000
    """
    Import data from iterator to Spark Dataframe
    """

    @staticmethod
    def correct_dtype_by_pandas(data):
        df = pd.DataFrame(data)
        t = df.dtypes
        rs = StructType()
        logger.info("Pandas type: %s" % ["%s:%s" % (k, v) for k, v in df.dtypes.items()])
        for col, t in t.items():
            if t == "int64":
                rs.add(StructField(col, types.LongType()))
            elif t == "int":
                rs.add(StructField(col, types.IntegerType()))
            elif t == "float64":
                rs.add(StructField(col, types.FloatType()))
            elif t == "bool":
                rs.add(StructField(col, types.BooleanType()))
            elif t == "datetime64":
                rs.add(StructField(col, types.DateType()))
            else:
                rs.add(StructField(col, types.StringType()))
        return rs

    @staticmethod
    @timeit
    def import_batch(data, session, schema):
        if schema is not None:
            df_temp = session.createDataFrame(data, schema)
        else:
            df_temp = session.createDataFrame(data)
        return df_temp

    @staticmethod
    def from_iterator(iter,
                      batch_size=DEFAULT_BATCH_SIZE,
                      transform_item=None,
                      spark_session=None,
                      schema=None,
                      auto_correct_schema=False,
                      **kwargs):
        """
        Create dataframe with list of data: [{"id" : 1,"name": "phong"},{"id" : 2,"name": "phong"}]

            iter: list data
            batch_size: data will split into batches, this is config of size of each batch
            transform_item: transform function if you want to transform each value
            spark_session:
            schema: Spark Schema DF of Spark
            kwargs:
            return:
        
        """
        from zuka_etl.custom.spark_hook import SparkHook
        f = generate_batches(iter, batch_size_limit=batch_size, callback_item=transform_item, remove_none=True)
        sp = spark_session if spark_session is not None else SparkHook().session
        df = None
        n = 0
        total = 0
        for batch in f:
            if auto_correct_schema is True and n == 0 and schema is None:
                schema = SparkDfFromIterator.correct_dtype_by_pandas(data=batch)
                logger.info("schema auto correct is: %s" % schema)
            df_temp = SparkDfFromIterator.import_batch(batch, sp, schema)
            if n <= 0:
                df = df_temp
            else:
                df = df.union(df_temp)
            total += len(batch)
            logger.info("Import to df: %s done!" % total)
            n += 1
        return df

    @staticmethod
    def from_iterator_with_checkpoint(iter, checkpoint_func, return_func, batch_size=DEFAULT_BATCH_SIZE,
                                      transform_item=None,
                                      spark_session=None,
                                      schema=None,
                                      auto_correct_schema=False,
                                      **kwargs):
        """
        Create dataframe with list of data: [{"id" : 1,"name": "phong"},{"id" : 2,"name": "phong"}]

            iter: list data
            checkpoint_func: function process a dataframe. Format: checkpoint_func(index_batch, df_batch)
            return_func: function output data: Format: return_func(spark_session)
            batch_size: data will split into batches, this is config of size of each batch
            transform_item: transform function if you want to transform each value
            spark_session:
            schema: Spark Schema DF of Spark
            kwargs:
            return:
        
        """
        from zuka_etl.custom.spark_hook import SparkHook
        if callable(checkpoint_func) is False:
            raise ValueError("checkpoint_func must be function")
        f = generate_batches(iter, batch_size_limit=batch_size, callback_item=transform_item, remove_none=True)
        sp = spark_session if spark_session is not None else SparkHook().session
        n = 0
        total = 0
        for batch in f:
            if auto_correct_schema is True and n == 0 and schema is None:
                schema = SparkDfFromIterator.correct_dtype_by_pandas(data=batch)
                logger.info("schema auto correct is: %s" % schema)
            df_temp = SparkDfFromIterator.import_batch(batch, sp, schema)
            logger.info("Process checkpoint from index: %s" % n)
            checkpoint_func(n, df_temp)
            total += len(batch)
            logger.info("Import to df: %s done!" % total)
            n += 1

        return return_func(sp)

    @staticmethod
    def from_iterator_with_checkpoint_hdfs(iter,
                                           write_function,
                                           return_function,
                                           batch_size=DEFAULT_BATCH_SIZE,
                                           transform_item=None,
                                           spark_session=None,
                                           schema=None, mode="append",
                                           auto_correct_schema=False,
                                           **kwargs):
        """
        Create dataframe with list of data: [{"id" : 1,"name": "phong"},{"id" : 2,"name": "phong"}]

            iter: list data
            write_function: callable function for writing data: write_function(p): p.format("parquet").save(path hdfs)
            return_function: function for output data: Format: return_function(spark_session)
            batch_size: data will split into batches, this is config of size of each batch
            transform_item: transform function if you want to transform each value
            spark_session:
            schema: Spark Schema DF of Spark
            mode: append or replace targer ouput
            kwargs:
            return:
        
        """
        if callable(write_function) is False:
            raise ValueError("write_function must be function")

        def checkpoint_func(index, df):
            c = df.write.mode("overwrite" if (index == 0 and mode == "replace") else "append")
            return write_function(c)

        return SparkDfFromIterator.from_iterator_with_checkpoint(iter=iter,
                                                                 checkpoint_func=checkpoint_func,
                                                                 return_func=return_function,
                                                                 batch_size=batch_size,
                                                                 transform_item=transform_item,
                                                                 spark_session=spark_session,
                                                                 schema=schema,
                                                                 auto_correct_schema=auto_correct_schema,
                                                                 **kwargs
                                                                 )
