from zuka_etl.log import logger
from zuka_etl.helpers.encryption import encryption
import pandas as pd


class PandasEncrypted(object):

    @staticmethod
    def to_encrypt(pd_df, key, iv, encrypted_fields=[]):
        """
        encrypt pandas dataframe
                    pd_df: pandas dataframe
                    key: key aes
                    iv: iv aes
                    encrypted_fields: encrypted fields of dataframe
                    return:
        """
        aes = encryption.AESCipher(key, iv)

        def encrypt(value):
            return aes.encrypt(value)

        if encrypted_fields is not None and len(encrypted_fields) > 0:
            for field in encrypted_fields:
                pd_df.loc[:, field] = pd_df.apply(lambda row: encrypt(row[field]), axis=1)
        return pd_df

    @staticmethod
    def to_decrypt(pd_df, key, iv, decrypted_fields=[]):
        """
        decrypt pandas dataframe
                    pd_df: pandas dataframe
                    key: key aes
                    iv: iv aes
                    encrypted_fields: encrypted fields of dataframe
                    return:
        """
        aes = encryption.AESCipher(key, iv)

        def decrypt(value):
            return aes.decrypt(value)

        if decrypted_fields is not None and len(decrypted_fields) > 0:
            for field in decrypted_fields:
                pd_df.loc[:, field] = pd_df.apply(lambda row: decrypt(row[field]), axis=1)
        return pd_df

