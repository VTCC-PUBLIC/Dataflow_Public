from zuka_etl.log import logger
from pyspark.sql import SparkSession
from zuka_etl.helpers.encryption import encryption
from pyspark.sql.types import StringType
from pyspark.sql.functions import udf, col


class SparkEncrypted:

    @staticmethod
    def to_encrypt(spark_df, key, iv, encrypted_fields=[]):
        """
        encrypt spark dataframe
                    spark_df: spark dataframe
                    key: key aes
                    iv: iv aes
                    encrypted_fields: encrypted fields of spark dataframe
                    return:
        """
        aes = encryption.AESCipher(key, iv)

        def encrypt(value):
            return aes.encrypt(value)

        encrypted_udf = udf(lambda value: encrypt(value), StringType())
        if encrypted_fields is not None and len(encrypted_fields) > 0:
            for field in encrypted_fields:
                spark_df = spark_df.withColumn(field, encrypted_udf(col(field)))
        return spark_df

    @staticmethod
    def to_decrypt(spark_df, key, iv, decrypted_fields=[]):
        """
        decrypt spark dataframe
                    spark_df: spark dataframe
                    key: key aes
                    iv: iv aes
                    decrypted_fields: decrypted fields of spark dataframe
                    return:
        """
        aes = encryption.AESCipher(key, iv)

        def decrypt(value):
            return aes.decrypt(value)

        decrypted_udf = udf(lambda value: decrypt(value), StringType())
        if decrypted_fields is not None and len(decrypted_fields) > 0:
            for field in decrypted_fields:
                spark_df = spark_df.withColumn(field, decrypted_udf(col(field)))
        return spark_df

