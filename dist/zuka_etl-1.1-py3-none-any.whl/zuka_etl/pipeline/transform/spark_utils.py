from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType


class SparkEncrypted:

    @staticmethod
    def to_encrypt(spark_df, key, iv, encrypted_fields=[]):
        """
        encrypt spark dataframe
                    spark_df: spark dataframe
                    key: key aes
                    iv: iv aes
                    encrypted_fields: encrypted fields of spark dataframe
                    return:
        """
        from zuka_etl.helpers.encryption import encryption
        aes = encryption.AESCipher(key, iv)

        def encrypt(value):
            return aes.encrypt(value)

        encrypted_udf = udf(lambda value: encrypt(value), StringType())
        if encrypted_fields is not None and len(encrypted_fields) > 0:
            for field in encrypted_fields:
                spark_df = spark_df.withColumn(field, encrypted_udf(col(field)))
        return spark_df

    @staticmethod
    def to_decrypt(spark_df, key, iv, decrypted_fields=[]):
        """
        decrypt spark dataframe
                    spark_df: spark dataframe
                    key: key aes
                    iv: iv aes
                    decrypted_fields: decrypted fields of spark dataframe
                    return:
        """
        from zuka_etl.helpers.encryption import encryption
        aes = encryption.AESCipher(key, iv)

        def decrypt(value):
            return aes.decrypt(value)

        decrypted_udf = udf(lambda value: decrypt(value), StringType())
        if decrypted_fields is not None and len(decrypted_fields) > 0:
            for field in decrypted_fields:
                spark_df = spark_df.withColumn(field, decrypted_udf(col(field)))
        return spark_df


class SparkTransCols:

    @staticmethod
    def trans_cols(df, is_clean_cols_name=False, transform_value={}):
        if is_clean_cols_name:
            from zuka_etl.helpers.sql import clean_col_name
            mark_duplicate = {}
            for k in df.columns:
                n_col = clean_col_name(k)
                if mark_duplicate.get(n_col) is None:
                    mark_duplicate[n_col] = 0
                else:
                    mark_duplicate[n_col] += 1
                rename_to = (n_col + ("" if mark_duplicate[n_col] == 0 else str(mark_duplicate[n_col])))
                df = df.withColumnRenamed(k, rename_to)
            del mark_duplicate
        if transform_value:
            col = df.columns
            select = []
            for k in col:
                if transform_value.get(k):
                    select.append(transform_value.get(k))
                else:
                    select.append("`%s` as %s" % (k, k))
            df = df.selectExpr(*select)
        return df
