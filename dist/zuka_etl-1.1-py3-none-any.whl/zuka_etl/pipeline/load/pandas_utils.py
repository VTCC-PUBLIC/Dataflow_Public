#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
from sqlalchemy import create_engine
from airflow.hooks.base_hook import BaseHook
import pandas as pd
import numpy as np
from zuka_etl.log import logger
import traceback
from zuka_etl.setting import Setting
from zuka_etl.helpers.time_utils import current_unixtime

import uuid
import os


class PandasDfToSQL(object):
    """
    Using SQLAchemy library to insert data to table sql
    """

    @staticmethod
    def to_sql(table, connection_id, pd_df, mode="append", database="", index=False, lower_col_name=False,
               create_engine_params={}, **kwargs):
        """
        Insert df to sql: mysql, oracle...
        
            table: table name
            connection_id: airflow connection id
            pd_df: pandas dataframe
            mode: append or replace
            database: name of database
            create_engine_params: params for create_engine function
            kwargs:
            return:
        
        """

        if table.find('.') > 0:
            database = table.split('.')[0]
            table = table.split('.')[1]
        config = BaseHook.get_connection(connection_id)
        uri = config.get_uri()
        if isinstance(create_engine_params, dict) and create_engine_params:
            db_connection = create_engine(uri, **create_engine_params)
        else:
            db_connection = create_engine(uri)
        logger.info(
            'Insert data to db: %s database/schema: %s, table: %s' % (config.host, database, table))
        if lower_col_name:
            pd_df.columns = map(str.lower, pd_df.columns)
        pd_df.to_sql(name=table,
                     con=db_connection,
                     if_exists=mode,
                     schema=database,
                     index=index,
                     **kwargs
                     )
        return True


class PandasDfToOther(object):
    @staticmethod
    def to_spark_df(pd_df, spark_session=None, schema=None, **kwargs):
        """
        convert pandas df to spark df

            pd_df: pandas df
            spark_session: pass SparkSession instance in case you want to custom spark context
            schema: spark dataframe schema
            kwargs:
            return:

        """
        from zuka_etl.custom.spark_hook import SparkHook
        spark = spark_session if spark_session is not None else SparkHook().session
        if schema is None:
            df = spark.createDataFrame(pd_df.astype(str))
        else:
            df = spark.createDataFrame(pd_df, schema=schema)
        return df

    @staticmethod
    def to_local_file(pd_df, file_name, path, file_type=None, output_func=None, **kwargs):
        """
        Save pandas dataframe to local file
        Args:
            pd_df: Pandas DataFrame
            file_name: File Name that will be saved on local storage
            file_type: Type of file: parquet, csv, json,txt
            path: Path that will be saved on local storage
            output_func: Function that you can implement writing function by yourself
            **kwargs:

        Returns:
        """
        tmp = "%s/%s" % (path.rstrip("/"), file_name)
        logger.info("File will be stored on: %s" % tmp)
        if file_type == "parquet":
            tmp += ".parquet"
            logger.info("Write df to tmp with parquet format: %s" % tmp)
            pd_df.to_parquet(tmp, compression=kwargs.get("compression", 'gzip'), **kwargs)
            if not str(file_name).endswith(".parquet"):
                file_name += ".parquet"
        elif file_type == "csv":
            tmp += ".csv"
            logger.info("Write df to tmp with csv format: %s" % tmp)
            pd_df.to_csv(tmp, **kwargs)
            if not str(file_name).endswith(".csv"):
                file_name += ".csv"
        elif file_type == "json":
            tmp += ".json"
            logger.info("Write df to tmp with json format: %s" % tmp)
            pd_df.to_json(tmp, orient='index')
            if not str(file_name).endswith(".json"):
                file_name += ".json"
        elif file_type == "txt":
            tmp += ".txt"
            logger.info("Write df to tmp with txt format: %s" % tmp)
            np.savetxt(tmp, pd_df.values, fmt='%d')
            if not str(file_name).endswith(".txt"):
                file_name += ".txt"
        elif callable(output_func):
            tmp = output_func(pd_df, tmp)
        else:
            raise ValueError("Your file_type: %s is not supported" % file_type)

        return tmp

    @staticmethod
    def to_hdfs(pd_df, file_name, hdfs_path, file_type=None, connection_id=None, output_func=None, **kwargs):
        """
        Save pandas df into a file on HDFS

        Note that: always overwrite target file if target file is exists on HDFS

            pd_df: pandas dataframe
            file_name: name file on HDFS
            file_path: path to save on HDFS
            connection_id: define HDFSHook connection on airflow
            file_type: file_format that will be stored on HDFS
                   only support: csv, parquet, txt, json
            output_func: if your file is out of allowed types, you can pass your custom function:
             Example: def output_func(pd_df, temp_path):
                          # your business
                          return temp_path
            mode: append or replace
            kwargs:
            return:

        """

        tmp = PandasDfToOther.to_local_file(pd_df=pd_df,
                                            file_type=file_type,
                                            file_name=("%s_%s" % (uuid.uuid4(), current_unixtime())),
                                            path=Setting.TEMP_FILE_PATH,
                                            output_func=output_func
                                            )

        from zuka_etl.pipeline.load.hdfs_utils import Hdfs
        try:
            Hdfs.upload_file(hdfs_path=hdfs_path + "/" + file_name,
                             local_path=tmp,
                             connection_id=connection_id,
                             **kwargs)
            return True
        except BaseException as e:
            logger.error("Error when put to HDFS: %s", traceback.format_exc())
            raise BaseException(traceback.format_exc())
        finally:
            try:
                os.remove(tmp)
            except BaseException  as e:
                logger.error("Error when remove file temp: %s\nError:%s" % (tmp, traceback.format_exc()))
        return False
