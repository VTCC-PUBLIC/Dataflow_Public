#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
from airflow.hooks.hdfs_hook import HDFSHook
from zuka_etl.log import logger
from zuka_etl.setting import Setting


class Hdfs(object):

    @staticmethod
    def upload_file(hdfs_path, local_path, connection_id=None, engine="hdfs_client", **kwargs):
        """
        upload file to HDFS
        
            hdfs_path: path that will be uploaded
            local_path: local file path
            connection_id: connection defined on airflow
            engine: mode to upload file
                   http: upload via http protocol
                   hdfs_client: upload via local hadoop client
            kwargs:
            return:

        """
        if engine == "http":
            from zuka_etl.custom.webhdfs_hook import WebClientHook
            logger.info("Put file to HDFS throw Hadoop Http: %s -> %s" % (local_path, hdfs_path))
            WebClientHook(connection_id=connection_id).get_engine().upload(hdfs_path, local_path, **kwargs)
        elif engine == "hdfs_client":
            logger.info("Put file to HDFS throw Hadoop Client: %s -> %s" % (local_path, hdfs_path))
            from zuka_etl.custom.hdfsclient_hook import HDFSClientHook
            HDFSClientHook(connection_id=connection_id).get_engine().put(local_path, hdfs_path, **kwargs)
        else:
            raise ValueError("engine: %s is not supported" % engine)
        return True
