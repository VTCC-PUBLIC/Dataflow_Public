#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

import pyspark
from airflow.hooks.jdbc_hook import JdbcHook

from zuka_etl.custom.spark_hook import SparkHook
from zuka_etl.helpers.exceptions import SparkDfEmptyException
# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
from zuka_etl.log import logger


class SparkDfToDriver(object):
    """
        Using driver that setup by JAR and Spark Session
    """
    MODE_APPEND = "append"
    MODE_OVERWRITE = "overwrite"
    MODE_APPEND_PARTITION = "append_partition"
    MODE_OVERWRITE_PARTITION = "append_overwrite"
    MODE_TRUNCATE = "truncate"
    MODE_UPSERT = "upsert"

    @staticmethod
    def cast_columns(df: pyspark.sql.DataFrame, columns: dict = {},
                     lowercase_columns: bool = True) -> pyspark.sql.DataFrame:
        """
                :param df:
                :param columns:
                :param lowercase_columns:
                :return:
        """
        cols = df.columns
        columns = {k.lower(): v.lower() for k, v in columns.items()}
        select = []
        for k in cols:
            l_k = k.lower()
            if columns.get(l_k):
                v = columns.get(l_k)
                select.append("CAST(`%s` as %s) as %s" % (k, v, l_k if lowercase_columns else k))
            else:
                select.append("`%s` as %s" % (k, l_k if lowercase_columns else k))
        if columns:
            logger.info("Columns will be casted: %s" % columns)
        return df.selectExpr(*select)

    @staticmethod
    def to_sql(table: str, connection_id: str, spark_df: pyspark.sql.DataFrame, mode: str = MODE_APPEND,
               lowercase_columns: bool = True, options: dict = {},
               cast_columns: dict = {},
               transform_columns: dict = {},
               empty_error: bool = False,
               sql_before="",
               sql_after="",
               **kwargs) -> bool:
        """
        Insert df to sql: mysql, oracle... by jdbc and spark
            table: table name
            connection_id: airflow connection id
            pd_df: pandas dataframe
            mode: append or overwrite
            lower_columns: lowercase all column names
            kwargs:
            return:

        """

        if empty_error:
            count = spark_df.take(1)
            if count:
                logger.info("Checking Your DataFrame is empty or not: pass!")
            else:
                raise SparkDfEmptyException()
        config = JdbcHook.get_connection(connection_id)
        spark_df = SparkDfToDriver.cast_columns(spark_df, cast_columns, lowercase_columns)
        table = table.strip()
        if transform_columns:
            from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
            spark_df = SparkTransCols.trans_cols(spark_df, transform_columns)
        if mode == SparkDfToDriver.MODE_TRUNCATE:
            mode = SparkDfToDriver.MODE_OVERWRITE
            options['truncate'] = True
        writer = spark_df.write.format("jdbc").mode(mode).option("url",
                                                                 config.host) \
            .option("dbtable", table) \
            .option("user", config.login) \
            .option("password", config.password) \
            .option("driver", config.extra_dejson.get("extra__jdbc__drv_clsname"))
        if isinstance(options, dict) and options:
            for k, v in options.items():
                writer = writer.option(k, v)
        if type(sql_before) is str and sql_before.strip() != "":
            sql_before = sql_before.strip().rstrip(";")
            sql_before = sql_before.split(';\n')
            connect = JdbcHook(connection_id)
            logger.info("Execute sql before insert into database")
            for k in sql_before:
                if k.strip() != '':
                    connect.run(sql=k, autocommit=True)
        elif callable(sql_before):
            logger.info("Execute function before insert into database")
            connect = JdbcHook(connection_id)
            sql_before(connect)

        logger.info("Start insert by spark to host: %s - table: %s" % (config.host, table))
        writer.save()
        logger.info("Insert by spark to host: %s - table: %s done!" % (config.host, table))
        if type(sql_after) is str and sql_after.strip() != "":
            sql_after = sql_after.strip().rstrip(";")
            sql_after = sql_after.split(';\n')
            connect = JdbcHook(connection_id)
            logger.info("Execute sql after insert into database")
            for k in sql_after:
                if k.strip() != '':
                    connect.run(sql=k, autocommit=True)
        elif callable(sql_after):
            logger.info("Execute function after insert into database")
            connect = JdbcHook(connection_id)
            sql_after(connect)
        return True

    # @staticmethod
    # def to_sql_2(table: str, connection_id: str, spark_df: pyspark.sql.DataFrame, mode: str = MODE_APPEND,
    #              lowercase_columns: bool = True, options: dict = {},
    #              cast_columns: dict = {},
    #              transform_columns: dict = {},
    #              empty_error: bool = False,
    #              sql_before="",
    #              sql_after="",
    #              upsert_config={},
    #              **kwargs) -> bool:
    #     """
    #     Insert df to sql: mysql, oracle... by jdbc and spark
    #         table: table name
    #         connection_id: airflow connection id
    #         pd_df: pandas dataframe
    #         mode: append or overwrite
    #         lower_columns: lowercase all column names
    #         kwargs:
    #         return:
    #
    #     """
    #
    #     if empty_error:
    #         count = spark_df.count()
    #         if count > 0:
    #             logger.info("Total data on DataFrame: %s" % count)
    #         else:
    #             raise SparkDfEmptyException()
    #     config = JdbcHook.get_connection(connection_id)
    #     spark_df = SparkDfToDriver.cast_columns(spark_df, cast_columns, lowercase_columns)
    #     table = table.strip()
    #     if transform_columns:
    #         from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
    #         spark_df = SparkTransCols.trans_cols(spark_df, transform_columns)
    #     if mode == SparkDfToDriver.MODE_TRUNCATE:
    #         mode = SparkDfToDriver.MODE_OVERWRITE
    #         options['truncate'] = True
    #     writer = spark_df.write.format("jdbc").mode(mode).option("url",
    #                                                              config.host) \
    #         .option("dbtable", table) \
    #         .option("user", config.login) \
    #         .option("password", config.password) \
    #         .option("driver", config.extra_dejson.get("extra__jdbc__drv_clsname"))
    #     if isinstance(options, dict) and options:
    #         for k, v in options.items():
    #             writer = writer.option(k, v)
    #     if type(sql_before) is str and sql_before.strip() != "":
    #         sql_before = sql_before.strip().rstrip(";")
    #         sql_before = sql_before.split(';\n')
    #         connect = JdbcHook(connection_id)
    #         logger.info("Execute sql before insert into database")
    #         for k in sql_before:
    #             if k.strip() != '':
    #                 logger.info("query: %s" % k)
    #                 connect.run(sql=k, autocommit=True)
    #     elif callable(sql_before):
    #         logger.info("Execute function before insert into database")
    #         connect = JdbcHook(connection_id)
    #         sql_before(connect)
    #
    #     logger.info("Start insert by spark to host: %s - table: %s" % (config.host, table))
    #     if mode == SparkDfToDriver.MODE_UPSERT:
    #         conflict_col_names = ", ".join(upsert_config.get("conflict_col_names"))
    #         metadata = SparkDfToDriver.parse_metadata(spark_df)
    #         sql_create_table = f"create table {table} if not exists (" \
    #                            + ", \n".join([f"{k} {v}" for k, v in metadata.items()]) \
    #                            + ")"
    #         logger.info("sql_create_table: " + sql_create_table)
    #         connect = JdbcHook(connection_id)
    #         connect.run(sql_create_table, autocommit=True)
    #
    #         def upsert(partitions):
    #             sql_list = []
    #             sql = """
    #                     INSERT INTO {{table_name}} ({{col_names}})
    #                     VALUES
    #                             {{col_values}}
    #                     ON CONFLICT ({{conflict_col_names}})
    #                     DO
    #                             UPDATE
    #                           SET {{val_change}};
    #                 """
    #             val_changes = [f"{col_name} = EXCLUDED.{col_name}" for col_name, _ in metadata.items()]
    #
    #             t_idx = 0
    #             timestamp_idx = []
    #             for col_name, col_type in metadata.items():
    #                 if col_type == "timestamp":
    #                     timestamp_idx.append(t_idx)
    #                 t_idx += 1
    #
    #             for row in partitions:
    #                 # values = [f"{str(row[i])}::timestamp" if i in timestamp_idx elif row[i] else row[i] for i in range(len(row))]
    #                 sql_list.append(f"({', '.join(values)})")
    #                 if len(sql_list) >= 20000:
    #                     new_sql = sql.replace("{{table_name}}", table) \
    #                         .replace("{{col_names}}", ", ".join([col_name for col_name, _ in metadata.items()])) \
    #                         .replace("{{col_values}}", ", ".join(sql_list)) \
    #                         .replace("{{conflict_col_names}}", conflict_col_names) \
    #                         .replace("{{val_change}}", ", ".join(val_changes))
    #                     sql_list = []
    #                     connect.run(sql=new_sql, autocommit=True)
    #             if len(sql_list) > 0:
    #                 new_sql = sql.replace("{{table_name}}", table) \
    #                     .replace("{{col_names}}", ", ".join([col_name] for col_name, _ in metadata.items())) \
    #                     .replace("{{col_values}}", ", ".join(sql_list)) \
    #                     .replace("{{conflict_col_names}}", conflict_col_names) \
    #                     .replace("{{val_change}}", ", ".join(val_changes))
    #                 connect.run(sql=new_sql, autocommit=True)
    #
    #         # def upsert_2():
    #         #     pass
    #         #
    #         def create_merge_db():
    #             sql = f"""
    #                 CREATE OR REPLACE FUNCTION merge_db({{col_names}}) RETURNS VOID AS
    #                 $$
    #                 BEGIN
    #                     LOOP
    #                         -- first try to update the key
    #                         UPDATE {table} SET {{val_change}} WHERE {{conflict_col_names}};
    #                         IF found THEN
    #                             RETURN;
    #                         END IF;
    #                         -- not there, so try to insert the key
    #                         -- if someone else inserts the same key concurrently,
    #                         -- we could get a unique-key failure
    #                         BEGIN
    #                             INSERT INTO {table}(name, email, active) VALUES (name_data, email_data, active_data);
    #                             RETURN;
    #                         EXCEPTION WHEN unique_violation THEN
    #                             -- Do nothing, and loop to try the UPDATE again.
    #                         END;
    #                     END LOOP;
    #                 END;
    #                 $$
    #                 LANGUAGE plpgsql;
    #             """
    #             connect.run(sql=sql, autocommit=True)
    #
    #         spark_df.repartition(upsert_config.get("num_partitions", 10)).foreachPartition(upsert)
    #     else:
    #         writer.save()
    #     logger.info("Insert by spark to host: %s - table: %s done!" % (config.host, table))
    #     if type(sql_after) is str and sql_after.strip() != "":
    #         sql_after = sql_after.strip().rstrip(";")
    #         sql_after = sql_after.split(';\n')
    #         connect = JdbcHook(connection_id)
    #         logger.info("Execute sql after insert into database")
    #         for k in sql_after:
    #             if k.strip() != '':
    #                 logger.info("query: %s" % k)
    #                 connect.run(sql=k, autocommit=True)
    #     elif callable(sql_after):
    #         logger.info("Execute function after insert into database")
    #         connect = JdbcHook(connection_id)
    #         sql_after(connect)
    #     return True

    @staticmethod
    def to_hive(table: str, spark_df: pyspark.sql.DataFrame, mode: str = MODE_APPEND, format: str = "orc",
                lowercase_columns: bool = True,
                options: dict = {},
                cast_columns: dict = {},
                transform_columns: dict = {},
                partition_by: list = [],
                empty_error: bool = False,
                **kwargs) -> bool:
        """
        Insert df to hive table
            :param table: hive table name
            :param spark_df: spark_dataframe
            :param mode: overwrite or append
            :param format: orc, parquet, csv..
            :param lowercase_columns: lower all columns or not
            :param options: options for spark writer
            :param partition_by: list fields will be used to partition
            :param kwargs:
            :return:
        """
        import pyspark
        if empty_error:
            count = spark_df.take(1)
            if count:
                logger.info("Checking Your DataFrame is empty or not: pass!")
            else:
                raise SparkDfEmptyException()
        spark_df = SparkDfToDriver.cast_columns(spark_df, cast_columns, lowercase_columns)
        writer = spark_df.write
        table = table.strip()
        if transform_columns:
            from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
            spark_df = SparkTransCols.trans_cols(spark_df, transform_columns)
        if mode in [SparkDfToDriver.MODE_APPEND_PARTITION,
                    SparkDfToDriver.MODE_OVERWRITE_PARTITION,
                    SparkDfToDriver.MODE_APPEND]:
            try:
                cols = [k[0] for k in SparkHook().run_sql("show columns in %s" % table, log=False).collect()]
                logger.info("Columns will be inserted: %s" % cols)
                writer = spark_df.select(*cols).write
                if isinstance(options, dict) and options:
                    for k, v in options.items():
                        writer = writer.option(k, v)
            except pyspark.sql.utils.AnalysisException as e:
                t = table.split(".")
                t = t[0] if len(t) == 1 else t[1]
                if (str(e).find("Table or view '%s' not found" % t) >= 0):
                    mode = SparkDfToDriver.MODE_OVERWRITE
                    writer = spark_df.write
                else:
                    raise pyspark.sql.utils.AnalysisException(e, e)

        if mode in [SparkDfToDriver.MODE_APPEND_PARTITION,
                    SparkDfToDriver.MODE_OVERWRITE_PARTITION
                    ]:
            c = {
                "hive.exec.dynamic.partition.mode": "nonstrict",
                "spark.sql.sources.partitionOverwriteMode": "dynamic"
            }
            logger.info("""Check spark.conf must have config: %s to prevent loss data (replace entire table)""" % c)
            conf = SparkHook().session.sparkContext.getConf()
            for k, v in c.items():
                if conf.get(k) != v:
                    raise SystemError("You must config SparkConf with %s=%s" % (k, v))
            logger.info("Start insert hive table with mode partition: {%s} - {%s}" % (mode, table))
            writer.format(format).insertInto(table, overwrite=mode == SparkDfToDriver.MODE_OVERWRITE_PARTITION)
            logger.info("Insert hive table with mode partition: {%s} - {%s} done!" % (mode, table))
        elif mode in [SparkDfToDriver.MODE_OVERWRITE, SparkDfToDriver.MODE_APPEND]:
            writer = writer.mode(mode).format(format)
            logger.info("Start insert hive table by spark - table:{%s} {%s}" % (mode, table))
            writer.saveAsTable(table, partitionBy=partition_by)
            logger.info("Insert hive table: table:{%s} {%s} done!" % (mode, table))
        else:
            raise ValueError("mode: %s is invalid" % mode)
        return True

    @staticmethod
    def parse_metadata(spark_df):
        from collections import OrderedDict
        schema_dict = OrderedDict()
        schema_parse_table = {
            "timestamp": "timestamp",
            "string": "text",
            "int": "integer",
            "boolean": "boolean"
        }
        for dtype in spark_df.dtypes:
            if "decimal" in str(dtype[1]):
                schema_dict[str(dtype[0])] = str(dtype[1]).replace("decimal", "numeric")
            else:
                schema_dict[str(dtype[0])] = schema_parse_table[str(dtype[1])]
        return schema_dict
