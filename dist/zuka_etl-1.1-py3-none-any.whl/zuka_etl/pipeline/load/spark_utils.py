#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

import pyspark
from airflow.hooks.jdbc_hook import JdbcHook

from zuka_etl.custom.spark_hook import SparkHook
from zuka_etl.helpers.exceptions import SparkDfEmptyException
# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
from zuka_etl.log import logger


class SparkDfToDriver(object):
    """
        Using driver that setup by JAR and Spark Session
    """
    MODE_APPEND = "append"
    MODE_OVERWRITE = "overwrite"
    MODE_APPEND_PARTITION = "append_partition"
    MODE_OVERWRITE_PARTITION = "append_overwrite"

    @staticmethod
    def cast_columns(df: pyspark.sql.DataFrame, columns: dict = {},
                     lowercase_columns: bool = True) -> pyspark.sql.DataFrame:
        """
                :param df:
                :param columns:
                :param lowercase_columns:
                :return:
        """
        cols = df.columns
        columns = {k.lower(): v.lower() for k, v in columns.items()}
        select = []
        for k in cols:
            l_k = k.lower()
            if columns.get(l_k):
                v = columns.get(l_k)
                select.append("CAST(%s as %s) as %s" % (k, v, l_k if lowercase_columns else k))
            else:
                select.append("%s as %s" % (k, l_k if lowercase_columns else k))
        if columns:
            logger.info("Columns will be casted: %s" % columns)
        return df.selectExpr(*select)

    @staticmethod
    def to_sql(table: str, connection_id: str, spark_df: pyspark.sql.DataFrame, mode: str = MODE_APPEND,
               lowercase_columns: bool = True, options: dict = {},
               cast_columns: dict = {},
               transform_columns: dict = {},
               empty_error: bool = False,
               **kwargs) -> bool:
        """
        Insert df to sql: mysql, oracle... by jdbc and spark
            table: table name
            connection_id: airflow connection id
            pd_df: pandas dataframe
            mode: append or overwrite
            lower_columns: lowercase all column names
            kwargs:
            return:

        """

        if empty_error:
            count = spark_df.count()
            if count > 0:
                logger.info("Total data on DataFrame: %s" % count)
            else:
                raise SparkDfEmptyException()
        config = JdbcHook.get_connection(connection_id)
        spark_df = SparkDfToDriver.cast_columns(spark_df, cast_columns, lowercase_columns)
        if transform_columns:
            from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
            spark_df = SparkTransCols.trans_cols(spark_df, transform_columns)
        writer = spark_df.write.format("jdbc").mode(mode).option("url",
                                                                 config.host) \
            .option("dbtable", table) \
            .option("user", config.login) \
            .option("password", config.password) \
            .option("driver", config.extra_dejson.get("extra__jdbc__drv_clsname"))
        if isinstance(options, dict) and options:
            for k, v in options.items():
                writer = writer.option(k, v)
        logger.info("Start insert by spark to host: %s - table: %s" % (config.host, table))
        writer.save()
        logger.info("Insert by spark to host: %s - table: %s done!" % (config.host, table))
        return True

    @staticmethod
    def to_hive(table: str, spark_df: pyspark.sql.DataFrame, mode: str = MODE_APPEND, format: str = "orc",
                lowercase_columns: bool = True,
                options: dict = {},
                cast_columns: dict = {},
                transform_columns: dict = {},
                partition_by: list = [],
                empty_error: bool = False,
                **kwargs) -> bool:
        """
        Insert df to hive table
            :param table: hive table name
            :param spark_df: spark_dataframe
            :param mode: overwrite or append
            :param format: orc, parquet, csv..
            :param lowercase_columns: lower all columns or not
            :param options: options for spark writer
            :param partition_by: list fields will be used to partition
            :param kwargs:
            :return:
        """
        import pyspark
        if empty_error:
            count = spark_df.count()
            if count > 0:
                logger.info("Total data on DataFrame: %s" % count)
            else:
                raise SparkDfEmptyException()
        spark_df = SparkDfToDriver.cast_columns(spark_df, cast_columns, lowercase_columns)
        writer = spark_df.write
        if transform_columns:
            from zuka_etl.pipeline.transform.spark_utils import SparkTransCols
            spark_df = SparkTransCols.trans_cols(spark_df, transform_columns)
        if mode in [SparkDfToDriver.MODE_APPEND_PARTITION,
                    SparkDfToDriver.MODE_OVERWRITE_PARTITION,
                    SparkDfToDriver.MODE_APPEND]:
            try:
                cols = [k[0] for k in SparkHook().run_sql("show columns in %s" % table, log=False).collect()]
                logger.info("Columns will be inserted: %s" % cols)
                writer = spark_df.select(*cols).write
                if isinstance(options, dict) and options:
                    for k, v in options.items():
                        writer = writer.option(k, v)
            except pyspark.sql.utils.AnalysisException as e:
                t = table.split(".")
                t = t[0] if len(t) == 1 else t[1]
                if (str(e).find("Table or view '%s' not found" % t) >= 0):
                    mode = SparkDfToDriver.MODE_OVERWRITE
                    writer = spark_df.write
                else:
                    raise pyspark.sql.utils.AnalysisException(e, e)

        if mode in [SparkDfToDriver.MODE_APPEND_PARTITION,
                    SparkDfToDriver.MODE_OVERWRITE_PARTITION
                    ]:
            c = {
                "hive.exec.dynamic.partition.mode": "nonstrict",
                "spark.sql.sources.partitionOverwriteMode": "dynamic"
            }
            logger.info("""Check spark.conf must have config: %s to prevent loss data (replace entire table)""" % c)
            conf = SparkHook().session.sparkContext.getConf()
            for k, v in c.items():
                if conf.get(k) != v:
                    raise SystemError("You must config SparkConf with %s=%s" % (k, v))
            logger.info("Start insert hive table with mode partition: {%s} - {%s}" % (mode, table))
            writer.format(format).insertInto(table, overwrite=mode == SparkDfToDriver.MODE_OVERWRITE_PARTITION)
            logger.info("Insert hive table with mode partition: {%s} - {%s} done!" % (mode, table))
        elif mode in [SparkDfToDriver.MODE_OVERWRITE, SparkDfToDriver.MODE_APPEND]:
            writer = writer.mode(mode).format(format)
            logger.info("Start insert hive table by spark - table:{%s} {%s}" % (mode, table))
            writer.saveAsTable(table, partitionBy=partition_by)
            logger.info("Insert hive table: table:{%s} {%s} done!" % (mode, table))
        else:
            raise ValueError("mode: %s is invalid" % mode)
        return True
