#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
import copy
from zuka_etl.log import logger
from zuka_etl.utils import timeit


class Process(object):
    """
    Process ETL pipeline

        Example:
            from zuka_etl.db.connect_spark import SparkWrapper
    
            def ex(this):
                this.logger.info("This is extract function")
                this.set_shipper("a", "11")
                return 1
    
            def trans(this, value):
                this.logger.info("This is transform function")
                print(value)
                return value
    
            def load(this, value):
                this.logger.info("This is load function")
                print(value)
                this.logger.info(this.get_shipper("a"))
                # save every thing you want
    
            Process(
                task_id="phong",
                extract=ex,
                transform=tras,
                load=load,
                complete=lamdba x: x
            ).run()
    
    """
    extract_func = None
    transform_func = None
    load_func = None
    complete_func = None

    shipper = {}
    task_id = ""
    additional_args = {}
    additional_kwargs = {}
    self_instance_key = "pipeline"

    def __init__(self, task_id, extract, transform=None, load=None, complete=None, additional_args=None,
                 additional_kwargs=None):
        """

        Run a ETL Pipeline

            extract:
                ex: function(this)
            transform:
                ex: function(this, extract_value)
            load:
                ex: function(this, transform_value)
            args
            kwargs

        """
        self.task_id = task_id
        self.extract_func = extract
        self.transform_func = transform
        self.load_func = load
        self.shipper = {}
        self.complete_func = complete
        self.additional_args = copy.copy(additional_args or [])
        self.additional_kwargs = copy.copy(additional_kwargs or {})

    @property
    def logger(self):
        return logger

    @property
    def extract_kargs(self):
        return self.additional_kwargs

    def set_shipper(self, key, value):
        if not hasattr(self, "shipper"):
            self.shipper = {}
        self.shipper[key] = value

    def get_shipper(self, key, default=None):
        if not hasattr(self, "shipper"):
            self.shipper = {}
        return self.shipper.get(key, default)

    def get_shippers(self):
        return self.shipper

    @timeit
    def extract(self):
        if callable(self.extract_func):
            self.logger.info(
                "[Extract] ************ Start run extract function on task: %s ************" % self.task_id)
            args = self.extract_func.__code__.co_varnames
            self.logger.info("[Extract] Params of extract_function: %s" % ",".join(args))
            if self.self_instance_key in args \
                    and self.self_instance_key not in self.additional_args \
                    and self.self_instance_key not in self.additional_kwargs.keys():
                return self.extract_func(self, *self.additional_args, **self.additional_kwargs)
            return self.extract_func(*self.additional_args, **self.additional_kwargs)
        else:
            logger.info("[Complete] Skip run Extract function because not defined")
        return None

    @timeit
    def transform(self, extract_value):
        if callable(self.transform_func):
            self.logger.info(
                "[Transform] ************ Start run transform function on task: %s ************" % self.task_id)
            args = self.transform_func.__code__.co_varnames
            self.logger.info("[Transform] Params of transform_function:: %s" % ",".join(args))
            if self.self_instance_key in args \
                    and self.self_instance_key not in self.additional_args \
                    and self.self_instance_key not in self.additional_kwargs.keys():
                return self.transform_func(self, extract_value)
            return self.transform_func(extract_value)
        else:
            logger.info("[Complete] Skip run Transform function because not defined")
        return extract_value

    @timeit
    def load(self, transform_value):
        if callable(self.load_func):
            self.logger.info("[Load] ************ Start run load function on task: %s ************" % self.task_id)
            args = self.load_func.__code__.co_varnames
            self.logger.info("[Load] Params of load_function: %s" % (str(args)))
            if self.self_instance_key in args \
                    and self.self_instance_key not in self.additional_args \
                    and self.self_instance_key not in self.additional_kwargs.keys():
                return self.load_func(self, transform_value)
            return self.load_func(transform_value)
        else:
            logger.info("[Complete] Skip run Load function because not defined")
        return None

    @timeit
    def complete(self, trans_value, load_value):
        if callable(self.complete_func):
            self.logger.info(
                "[Complete] ************ Start run complete function on task: %s ************" % self.task_id)
            args = self.complete_func.__code__.co_varnames
            self.logger.info("[Complete] Params of complete_function: %s" % (str(args)))
            if self.self_instance_key in args \
                    and self.self_instance_key not in self.additional_args \
                    and self.self_instance_key not in self.additional_kwargs.keys():
                return self.complete_func(self, trans_value, load_value)
            return self.load_func(trans_value, load_value)
        else:
            logger.info("[Complete] Skip run Complete function because not defined")
        return None

    def run(self):
        self.logger.info("***** Start run task: {{%s}} *****" % self.task_id)
        ex = self.extract()
        trans = self.transform(extract_value=ex)
        if trans is None:
            trans = ex
        load = self.load(transform_value=trans)
        if load is None:
            load = trans
        self.complete(trans_value=trans, load_value=load)
