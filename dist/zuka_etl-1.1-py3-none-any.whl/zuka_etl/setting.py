"""
@author: phong pham hong
"""
import os

import os

# set enviroment in dev mode

# import findspark
#
# findspark.init('/var/python_env/env3.6/lib/python3.6/site-packages/pyspark')
from zuka_etl.log import logger
from datetime import datetime
from datetime import datetime, timedelta
from airflow.models import Variable


class Setting(object):
    ENVIRONMENT = 'dev'

    APPLICATION_ROOT_PATH = os.path.dirname(__file__).replace('\\', '/').replace('/zuka_etl', '')
    _instance = None

    LOG_JOB_PATH = 'log'

    LOCAL_TIME_ZONE = Variable.get("LOCAL_TIME_ZONE", "Asia/Bangkok")
    TEMP_FILE_PATH = Variable.get("TEMP_FILE_PATH", "/tmp/zuka_etl/")
    YARN_HOST = Variable.get("YARN_HOST", os.getenv("YARN_HOST", ""))
    HDFS_HOST = Variable.get("HDFS_HOST", os.getenv("HDFS_HOST", ""))
    SPARK_CONFIG_DEFAULT = Variable.get("SPARK_CONFIG_DEFAULT", "spark_connection_default")
    SPARK_CONFIG_SUBMIT_DEFAULT = Variable.get("SPARK_CONFIG_SUBMIT_DEFAULT", "spark_connection_default_submit")


if __name__ == "__main__":
    print(Setting.YARN_HOST)
