#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode

import datetime
import json
import time

import six
from airflow.api.common.experimental.trigger_dag import trigger_dag
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from airflow.exceptions import AirflowTaskTimeout, AirflowException
from airflow.hooks.base_hook import BaseHook
from airflow.models import BaseOperator
from airflow.models.dagrun import DagRun
from airflow.operators.dagrun_operator import DagRunOrder
# from zuka_etl.log import logger
from airflow.operators.python_operator import PythonOperator
from airflow.utils import timezone
from airflow.utils.decorators import apply_defaults

from zuka_etl.log import logger
from zuka_etl.pipeline.process import Process
from zuka_etl.setting import Setting


class EtlOperator(PythonOperator):
    """
    Process ETL pipeline

        Example:

            def ex(pipeline):
                pipeline.logger.info("This is extract function")
                pipeline.set_shipper("a", "11")
                return 1

            def transform(pipeline, value):
                pipeline.logger.info("This is transform function")
                print(value)
                return value

            def load(pipeline, value):
                pipeline.logger.info("This is load function")
                print(value)
                pipeline.logger.info(pipeline.get_shipper("a"))
                # save every thing you want

            EtlOperator(
                task_id="phong",
                extract=ex,
                transform=tras,
                load=load
            )
    """

    @apply_defaults
    def __init__(
            self,
            extract,  # type: Callable
            transform=None,  # type: Callable
            load=None,  # type: Callable
            extract_kwargs=None,  # type: Optional[Dict]
            provide_context=False,  # type: bool
            templates_dict=None,  # type: Optional[Dict]
            templates_exts=None,  # type: Optional[Iterable[str]]
            *args,
            **kwargs
    ):
        super(EtlOperator, self).__init__(
            python_callable=extract,
            op_args=None,
            op_kwargs=None,
            provide_context=provide_context,
            templates_dict=templates_dict,
            templates_exts=templates_exts, *args, **kwargs)
        self.python_callable_object = self.build_pipeline(task_id=self.task_id,
                                                          extract=extract,
                                                          transform=transform,
                                                          load=load, additional_args=None,
                                                          additional_kwargs=extract_kwargs).run

    @staticmethod
    def build_pipeline(task_id, extract, transform, load, additional_args, additional_kwargs):
        return Process(task_id, extract=extract, transform=transform, load=load, additional_args=additional_args,
                       additional_kwargs=additional_kwargs)

    def execute(self, context):
        self.python_callable_object.dag_context = context
        self.python_callable = self.python_callable_object.run
        super(EtlOperator, self).execute(context=context)


class SparkSubmitOperator(SparkSubmitOperator):
    """
    Process Submit

        Example:
            from zuka_etl.custom.operator import SparkSubmitOperator

            ZukaSubmitOperator(
                task_id="phong",
                java_class = "",
                application = "/home/projects/job.jar",
                dag = dag_config
            )

    This hook is a wrapper around the SparkSubmitOperator to kick off a spark-submit job.
    It requires that the "spark-submit" binary is in the PATH or the spark-home is set
    in the extra on the connection.

        Parameters:
            application: str, the application that submitted as a job,  either jar or 
                py file. (templated)
            conf: dict, arbitrary Spark configuration properties (templated)            
            conn_id: str, the connection id as configured in Airflow  administration. 
                When an invalid connection_id  is supplied, it will default to yarn.
            files: str, upload additional files to the executor running the job, 
                separated by a comma. Files will be placed in the working directory 
                of each executor.
                    For example, serialized objects. (templated)
            py_files: str, additional python files used by the job, can be .zip, .egg 
                or .py. (templated)
            jars: str, submit additional jars to upload and place them in executor 
                classpath. (templated)
            driver_class_path: str, additional, driver-specific, classpath 
                settings. (templated)
            java_class: str, the main class of the Java application
            packages: str, comma-separated list of maven coordinates of  jars to 
                include on the driver and executor classpaths. (templated)
            exclude_packages: str, comma-separated list of maven coordinates 
                of jars to exclude while resolving the dependencies provided in 
                'packages' (templated)
            repositories: str, comma-separated list of additional remote repositories 
                to search for the maven coordinates given with 'packages'
            total_executor_cores: int, (Standalone & Mesos only) total cores for all 
                executors (Default: all the available cores on the worker)
            executor_cores: int (Standalone & YARN only) Number of cores 
                per executor (Default: 2)
            executor_memory: str, memory per executor 
                (e.g. 1000M, 2G) (Default: 1G)
            driver_memory: str, memory allocated to the driver 
                (e.g. 1000M, 2G) (Default: 1G)
            keytab: str, full path to the file that contains the keytab (templated)
            principal: str, the name of the kerberos principal used 
                for keytab (templated)
            proxy_user: str, user to impersonate when submitting the 
                application (templated)
            name: str, name of the job (default airflow-spark). (templated)
            num_executors: int, number of executors to launch
            application_args: list, arguments for the application being 
                submitted (templated)
            env_vars: dict, environment variables for spark-submit. It supports 
                yarn and k8s mode too. (templated)
            verbose: bool, whether to pass the verbose flag to spark-submit process 
                for debugging
            spark_binary: str, the command to use for spark submit.
                                 Some distros may use spark2-submit.

    """

    @apply_defaults
    def __init__(self,
                 application,
                 conf={},
                 conn_id=Setting.SPARK_CONFIG_SUBMIT_DEFAULT,
                 files=None,
                 py_files=None,
                 archives=None,
                 driver_class_path=None,
                 jars=None,
                 java_class=None,
                 packages=None,
                 exclude_packages=None,
                 repositories=None,
                 total_executor_cores=None,
                 executor_cores=None,
                 executor_memory=None,
                 driver_memory=None,
                 keytab=None,
                 principal=None,
                 proxy_user=None,
                 name='zuka_etl_spark',
                 num_executors=None,
                 application_args=None,
                 env_vars=None,
                 verbose=False,
                 spark_binary="spark-submit",
                 *args,
                 **kwargs):
        hook = BaseHook.get_connection(conn_id=conn_id)
        name = name if name.strip() != "" else hook.get_app_name()
        cf_json = hook.extra_dejson
        spark_cf = cf_json.get("conf", conf)
        if isinstance(conf, dict) and conf:
            for k, v in conf.items():
                logger.info("Update spark_conf with %s: %s" % (k, v))
                spark_cf.update(k, v)

        if env_vars is None:
            env_vars = cf_json.get("env_vars", {})

        super(SparkSubmitOperator, self).__init__(
            application=application,
            conf=spark_cf,
            conn_id=conn_id,
            files=files,
            py_files=py_files,
            archives=archives,
            driver_class_path=driver_class_path,
            jars=jars,
            java_class=java_class,
            packages=packages,
            exclude_packages=exclude_packages,
            repositories=repositories,
            total_executor_cores=total_executor_cores,
            executor_cores=executor_cores,
            executor_memory=executor_memory,
            driver_memory=driver_memory,
            keytab=keytab,
            principal=principal,
            proxy_user=proxy_user,
            name=name,
            num_executors=num_executors,
            application_args=application_args,
            env_vars=env_vars,
            verbose=verbose,
            spark_binary=spark_binary,
            *args,
            **kwargs
        )

    def execute_env_vars(self, env_vars={}):
        import os
        try:
            for k, v in env_vars.items():
                logger.info('SET VARIABLE: %s:%s' % (k, v))
                os.environ[k] = v
        except BaseException as e:
            logger.info("Cannot import variable spark because:\n%s" % self.syslog.print_traceback())

    def execute(self, context):
        self.execute_env_vars(env_vars=self._env_vars)
        return super(SparkSubmitOperator, self).execute(context)


class SynTriggerDagRunOperator(BaseOperator):
    @apply_defaults
    def __init__(
            self,
            trigger_dag_id,
            python_callable=None,
            execution_date=None,
            scan_interval=20,
            *args, **kwargs):
        super(SynTriggerDagRunOperator, self).__init__(*args, **kwargs)
        self.python_callable = python_callable
        self.trigger_dag_id = trigger_dag_id
        self.scan_interval = scan_interval if scan_interval > 0 else 20
        if isinstance(execution_date, datetime.datetime):
            self.execution_date = execution_date.isoformat()
        elif isinstance(execution_date, six.string_types):
            self.execution_date = execution_date
        elif execution_date is None:
            self.execution_date = execution_date
        else:
            raise TypeError(
                'Expected str or datetime.datetime type '
                'for execution_date. Got {}'.format(
                    type(execution_date)))

    def execute(self, context):
        time_start = time.time()
        if self.execution_date is not None:
            run_id = 'trig__{}'.format(self.execution_date)
            self.execution_date = timezone.parse(self.execution_date)
        else:
            run_id = 'trig__' + timezone.utcnow().isoformat()
        dro = DagRunOrder(run_id=run_id)
        if self.python_callable is not None:
            dro = self.python_callable(context, dro)
        if dro:
            trigger_dag(dag_id=self.trigger_dag_id,
                        run_id=dro.run_id,
                        conf=json.dumps(dro.payload),
                        execution_date=self.execution_date,
                        replace_microseconds=False)
            dag_run = list(DagRun.find(run_id=run_id))
            dag_run = dag_run[0] if dag_run else None
            count = 0
            logger.info("Start wait dag: %s complete. Run_id is: %s. Execution_date: %s" % (
                self.trigger_dag_id, dro.run_id, self.execution_date))
            while dag_run is None or dag_run.get_state().lower().strip() == 'running':
                if count % 10 == 0:
                    logger.info("Still waiting...")
                    if dag_run is not None:
                        logger.info(dag_run.get_state())
                count += 1
                time.sleep(self.scan_interval)
                dag_run = list(DagRun.find(run_id=run_id))
                dag_run = dag_run[0] if dag_run else None
                time_run = time.time() - time_start
                if self.execution_timeout is not None and datetime.timedelta(seconds=time_run) > self.execution_timeout:
                    logger.error("Timeout exception...")
                    raise AirflowTaskTimeout
            if dag_run.get_state() == 'failed':
                logger.error("Dag:%s failed..." % (self.trigger_dag_id))
                raise AirflowException
            return 0
        else:
            self.log.info("Criteria not met, moving on")
