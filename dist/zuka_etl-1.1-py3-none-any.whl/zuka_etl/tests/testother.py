from zuka_etl.custom.spark_hook import SparkHook

if __name__ == "__main__":
    # a = SparkHook()
    # df1 = SparkHook().create_df_by_ldict(data=[
    #     {
    #         "id": 1, "name": "phong", "date": 1
    #     },
    #     {
    #         "id": 2, "name": "phong2", "date": 2
    #     }
    # ]).filter("id = 555")
    # # df = SparkHook().create_df_by_ldict(data="aaa")
    # from zuka_etl.pipeline.load.spark_utils import SparkDfToDriver
    #
    # print(SparkDfToDriver.to_hive(table=None, spark_df=df1, empty_error=True))
    def test(a: object):
        pass


    test("a")
