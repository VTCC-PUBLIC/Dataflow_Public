""""""
__author__ = 'vietvudanh'

from zuka_etl.helpers.encryption import encryption


def test_cipher():
    cases = [
        ("abcdefgh12345678", "Lox0nv7UWDw5Mdl2bkOYTg"),
        ("abcdefgh1234567", "sk_F4yqa3n49Kp8LXZVMYA"),
    ]
    aes = encryption.AESCipher("abcdefgh12345678", "abcdefgh12345678")
    for raw, enc in cases:
        raw_enc = aes.encrypt(raw)
        raw_dec = aes.decrypt(raw_enc)
        assert raw_enc == enc, f"{type(raw_enc)}:{raw_enc} != {type(enc)}{enc}"
        assert raw_dec == raw, f"{type(raw_dec)}:{raw_dec} != {type(raw)}{raw}"
