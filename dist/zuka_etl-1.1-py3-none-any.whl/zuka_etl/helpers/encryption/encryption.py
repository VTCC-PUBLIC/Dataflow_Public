"""encryption based on AES
add custom padding using 0x05 - \x05
"""
import base64
import hashlib
from Crypto import Random
from Crypto.Cipher import AES


def base64_encode(string):
    """
    Removes any `=` used as padding from the encoded string.
    """
    encoded: bytes = base64.urlsafe_b64encode(string)
    return encoded.decode('utf-8').rstrip("=")


def base64_decode(string):
    """
    Adds back in the required padding before decoding.
    """
    padding = 4 - (len(string) % 4)
    string = string + ("=" * padding)
    return base64.urlsafe_b64decode(string)


class AESCipher(object):

    def __init__(self, key, iv):
        self.pad_char = '\x05'
        self.bs = AES.block_size
        self.key = key
        self.iv = iv

    def encrypt(self, raw):
        raw = self._pad(raw)
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        enc = cipher.encrypt(raw.encode())
        return base64_encode(enc)

    def decrypt(self, enc):
        enc = base64_decode(enc)
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        decoded = cipher.decrypt(enc).decode('utf-8')
        first_pad_index = decoded.find(self.pad_char)
        if first_pad_index > 0:
            decoded = decoded[:first_pad_index]
        return decoded

    def _pad(self, s):
        if len(s) % self.bs != 0:
            return s + (self.bs - len(s) % self.bs) * self.pad_char
        return s
