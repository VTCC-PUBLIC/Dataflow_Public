""""""
__author__ = 'vietvudanh'

import pandas as pd


def fix_str_cols(df: pd.DataFrame) -> pd.DataFrame:
    """
    fix str columns to insert to spark
    :param df:
    :return:
    """
    for c in df.columns:
        if df[c].dtype == 'O':
            df[c] = df[c].astype(str)
    return df


def convert_time_cols(df: pd.DataFrame, time_cols: list, format: str):
    """
    fix time columns to insert to spark
    ```
        fix_time_col(df, ['time1'])
        fix_time_col(df, ['time1'], '%Y%m%d')
        fix_time_col(df, [('time1', '%Y%m%d'), 'time2'], '%Y%m%d %H%M%S')
    ```
    :param df:
    :param time_cols: list of col_name / list of tuple (col_name, format)
    :param format:
    :return:
    """
    for row in time_cols:
        fmt = format
        col = row
        if type(row) == tuple:
            col, col_format = row
            fmt = col_format or format
        if fmt is not None:
            df[col] = pd.to_datetime(df[col], format=fmt)
        else:
            df[col] = pd.to_datetime(df[col])
    return df
