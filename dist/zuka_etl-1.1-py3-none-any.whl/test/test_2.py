"""
Import a iterator to spark dataframe
"""
from zuka_etl.utils import render_date_range, convert_time, get_first_day_of_month, get_last_day_of_month, get_last_day_of_week, get_first_day_of_week
from zuka_etl.helpers.time_utils import convert_date_to_dim_date

d = render_date_range(from_date=convert_time("2018-01-01"), to_date=convert_time("2025-01-01"))

print([k for k in d])
from zuka_etl.pipeline.extract.spark_utils import SparkDfFromIterator
SparkDfFromIterator.from_iterator()