#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'
# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import re
import json


def parsing_schema():
    with open("../data/schema.sql") as f:

        with open("../data/result.json", "w") as w:
            for k in f.readlines():
                if k.find("CREATE TABLE") >= 0:
                    result = {}
                    table_name = (re.search(r"^(.*?)\(", k).group()).replace("CREATE TABLE", "").replace('"',
                                                                                                         '').replace(
                        "(", "").strip()
                    result["table"] = table_name
                    result["schema"] = ", ".join(
                        ["%s: %s" % (k.strip().split(" ")[:1][0], k.strip().split(" ")[1:2][0]) for k in
                         (" ".join(k.split("(")[1:]).replace(")", "").replace(",0", "").replace('"',
                                                                                                '').split(
                             ",")) if len(k.strip().split(" ")) >= 2])
                    w.write(json.dumps(result))
                    w.write("\n")


def pandas_csv():
    import pandas as pd
    with open("../data/result.json") as f:
        pd.read_json("../data/result.json", lines=True).to_csv("../data/Schema_ERP.csv", index=False)


if __name__ == "__main__":
    parsing_schema()
    pandas_csv()
