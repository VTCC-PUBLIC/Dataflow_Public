from setuptools import setup, find_packages


setup(
    name='zuka_etl',
    version='1.0',
    packages=find_packages(),
    url='',
    license='',
    author='phongph16',
    author_email='',
    description='',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)
