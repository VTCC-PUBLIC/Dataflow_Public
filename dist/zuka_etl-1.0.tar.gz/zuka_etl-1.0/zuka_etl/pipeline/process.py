#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode
import copy
from zuka_etl.log import logger
from zuka_etl.utils import timeit


class Process(object):
    """
    Process ETL pipeline

        Example:
            from zuka_etl.db.connect_spark import SparkWrapper
    
            def ex(this):
                this.logger.info("This is extract function")
                this.set_shipper("a", "11")
                return 1
    
            def trans(this, value):
                this.logger.info("This is transform function")
                print(value)
                return value
    
            def load(this, value):
                this.logger.info("This is load function")
                print(value)
                this.logger.info(this.get_shipper("a"))
                # save every thing you want
    
            Process(
                task_id="phong",
                extract=ex,
                transform=tras,
                load=load,
                complete=lamdba x: x
            ).run()
    
    """
    __extract_func = None
    __transform_func = None
    __load_func = None
    __complete_func = None

    __shipper = {}
    __task_id = ""
    __additional_args = None
    __additional_kwargs = None
    __self_instance_key = "pipeline"

    def __init__(self, task_id, extract, transform=None, load=None, complete=None, additional_args=None,
                 additional_kwargs=None):
        """

        Run a ETL Pipeline

            extract:
                ex: function(this)
            transform:
                ex: function(this, extract_value)
            load:
                ex: function(this, transform_value)
            args
            kwargs

        """
        self.__task_id = task_id
        self.__extract_func = extract
        self.__transform_func = transform
        self.__load_func = load
        self.__shipper = {}
        self.__complete_func = complete
        self.__additional_args = copy.copy(additional_args or [])
        self.__additional_kwargs = copy.copy(additional_kwargs or {})

    @property
    def logger(self):
        return logger

    @property
    def additional_args(self):
        return self.__additional_args

    @property
    def extract_kargs(self):
        return self.__additional_kwargs

    def set_shipper(self, key, value):
        self.__shipper[key] = value

    def get_shipper(self, key, default=None):
        return self.__shipper.get(key, default)

    def get_shippers(self):
        return self.__shipper

    @timeit
    def extract(self):
        if callable(self.__extract_func):
            args = self.__extract_func.__code__.co_varnames
            self.logger.info("[Extract] Params of extract_function: %s" % ",".join(args))
            if self.__self_instance_key in args \
                    and self.__self_instance_key not in self.__additional_args \
                    and self.__self_instance_key not in self.__additional_kwargs.keys():
                return self.__extract_func(self, *self.__additional_args, **self.__additional_kwargs)
            return self.__extract_func(*self.__additional_args, **self.__additional_kwargs)
        return None

    @timeit
    def transform(self, extract_value):
        if callable(self.__transform_func):
            args = self.__transform_func.__code__.co_varnames
            self.logger.info("[Transform] Params of transform_function:: %s" % ",".join(args))
            if self.__self_instance_key in args \
                    and self.__self_instance_key not in self.__additional_args \
                    and self.__self_instance_key not in self.__additional_kwargs.keys():
                return self.__transform_func(self, extract_value)
            return self.__transform_func(extract_value)
        return extract_value

    @timeit
    def load(self, transform_value):
        if callable(self.__load_func):
            args = self.__load_func.__code__.co_varnames
            self.logger.info("[Load] Params of load_function: %s" % (str(args)))
            if self.__self_instance_key in args \
                    and self.__self_instance_key not in self.__additional_args \
                    and self.__self_instance_key not in self.__additional_kwargs.keys():
                return self.__load_func(self, transform_value)
            return self.__load_func(transform_value)
        return None

    @timeit
    def complete(self, load_value):
        if callable(self.__complete_func):
            args = self.__complete_func.__code__.co_varnames
            self.logger.info("[Complete] Params of complete_function: %s" % (str(args)))
            if self.__self_instance_key in args \
                    and self.__self_instance_key not in self.__additional_args \
                    and self.__self_instance_key not in self.__additional_kwargs.keys():
                return self.__complete_func(self, load_value)
            return self.__load_func(load_value)
        return None

    def run(self):
        self.logger.info("***** Start run task: {{%s}} *****" % self.__task_id)
        self.logger.info("[Extract] ************ Start run extract function on task: %s ************" % self.__task_id)
        ex = self.extract()
        if callable(self.__transform_func):
            self.logger.info(
                "[Transform] ************ Start run transform function on task: %s ************" % self.__task_id)
            trans = self.transform(extract_value=ex)
        else:
            self.logger.info("Skip run Transform because not define function")
        if callable(self.__load_func):
            self.logger.info("[Load] ************ Start run load function on task: %s ************" % self.__task_id)
            load = self.load(transform_value=trans)
        else:
            self.logger.info("Skip run Load because not define function")
        if (callable(self.__complete_func)):
            self.logger.info(
                "[Complete] ************ Start run complete function on task: %s ************" % self.__task_id)
            self.complete(load_value=load)
