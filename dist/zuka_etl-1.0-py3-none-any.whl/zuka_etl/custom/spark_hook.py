#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/2/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from zuka_etl.setting import Setting
from zuka_etl.log import logger, traceback
import os
from pyspark.sql import HiveContext
from pyspark import SparkConf
from pyspark.sql import SparkSession
import pyspark.sql.functions as spark_functions
import pyspark.sql.types as spark_type
import copy
from airflow.models import Variable
import json
from airflow.hooks.base_hook import BaseHook


class SparkHook(BaseHook):
    """
    Wrapper Spark Context
    Define Connection on Connection on Airflow
    Note that just define connection name and extras as json config. Check example of config extras
        Example:
               {
                    "master": "local[*]",
                    "app_name": "etl_operator_spark",
                    "mode": "client",
                    "conf": {
                        "spark.jars.packages": "mysql:mysql-connector-java:5.1.47,org.elasticsearch:elasticsearch-hadoop:6.4.2",
                        "spark.dynamicAllocation.enabled": "true",
                        "spark.dynamicAllocation.maxExecutors": 5,
                        "spark.executor.cores": 4,
                        "spark.executor.memory": "2G",
                        "spark.shuffle.service.enabled": "true",
                        "spark.files.overwrite": "true",
                        "spark.sql.warehouse.dir": "/apps/spark/warehouse",
                        "spark.sql.catalogImplementation": "hive",
                        "spark.sql.sources.partitionOverwriteMode": "dynamic",
                        "hive.exec.dynamic.partition.mode": "nonstrict",
                        "spark.sql.caseSensitive": "true"
                    },
                    "env_vars": {
                        "SPARK_HOME": ""
                    },
                    "add_py_file": ["test.py"]
                }
    """
    __DEFAULT_CONNECT = Setting.SPARK_CONFIG_DEFAULT
    _instance = {}
    __app_name = ""
    __master = ""
    __mode = ""
    __ENV = {}

    def __init__(self, connection_id="",
                 app_name="",
                 master="",
                 mode="",
                 spark_conf={},
                 env_vars={},
                 py_files=[],
                 auto_find_pyspark=False,
                 enable_hive_support=True,
                 **kwargs):
        """
        Call SparkContext
            Parameters:
                kwargs:
                    connection_id: id of connection
                    app_name: spark app name
                    master: local or YARN
                    mode: mode run on YARN
                    spark_conf: overwrite some default configs of spark.
                                Format: Example:
                                   {
                                        'spark.jars.packages': 'mysql:mysql-connector-java:5.1.47,org.elasticsearch:elasticsearch-hadoop:6.4.2',
                                        'spark.dynamicAllocation.enabled': "true",
                                        'spark.dynamicAllocation.maxExecutors': 5,
                                        'spark.executor.cores': 4,
                                        'spark.executor.memory': '2G',
                                        'spark.shuffle.service.enabled': "true",
                                        "spark.files.overwrite": "true",
                                        "spark.sql.warehouse.dir": "/apps/spark/warehouse",
                                        "spark.sql.catalogImplementation": "hive",
                                        "spark.sql.sources.partitionOverwriteMode": "dynamic",
                                        "hive.exec.dynamic.partition.mode": "nonstrict",
                                        "spark.sql.caseSensitive": "true"
                                   }
                    env_vars: add some env variables. Example: {
                        "SPARK_HOME": "/usr/hdp/current/spark2/"
                    }
                    add_py_files: Add some python file path when submit job. Example: ["test.py"]}
                    auto_find_pyspark: True or False. If true, automatic find pyspark environment by findpspark package

        """
        self.__app_name = app_name.strip()
        self.__master = master.strip()
        self.__mode = mode.strip()
        custom_config = copy.copy(spark_conf if isinstance(spark_conf, dict) else {})
        env_vars = copy.copy(env_vars if isinstance(env_vars, dict) else {})
        add_py_files = py_files if isinstance(py_files, list) else []
        self.__auto_find_pyspark = auto_find_pyspark if isinstance(auto_find_pyspark, bool) else False
        self.__enable_hive_support = enable_hive_support if isinstance(enable_hive_support, bool) else False
        self.__load_config = {}
        self.syslog = logger
        connection_id = connection_id.strip() if connection_id.strip() != "" else SparkHook.__DEFAULT_CONNECT
        cn = self.get_connection(conn_id=connection_id)
        if cn.extra_dejson:
            self.__load_config = cn.extra_dejson
        else:
            logger.warn("Config for sparkContext of SparkHook is not set. Using default config")
        if self.__app_name != "":
            self.__load_config["app_name"] = self.__app_name.strip()
        else:
            self.__app_name = self.__load_config.get("app_name", "Zuka_etl_spark")
        if self.__master != "":
            self.__load_config["master"] = self.__master
        else:
            self.__master = self.__load_config.get("master", "local[*]")
        if self.__mode != "":
            self.__load_config["mode"] = self.__mode
        else:
            self.__mode = self.__load_config.get("mode", "")
        if custom_config:
            sp_cf = self.__load_config.get("conf", {})
            if not isinstance(sp_cf, dict):
                sp_cf = {}
                self.__load_config["conf"] = sp_cf
            self.__load_config["conf"].update(custom_config)
        if env_vars:
            env = self.__load_config.get("env_vars", {})
            if not isinstance(env, dict):
                env = {}
                self.__load_config["env_vars"] = env
            self.__load_config["env_vars"].update(custom_config)
        if add_py_files:
            add = self.__load_config.get("py_files", [])
            if not isinstance(add, list):
                self.__load_config["py_files"] = []
            self.__load_config["py_files"] = add_py_files

    def get_app_name(self):
        return self.__app_name

    def get_master(self):
        return self.__app_name

    def get_mode(self):
        return self.__app_name

    def get_list_instance(self):
        return self._instance

    def get_conn(self):
        return self.session

    def get_config(self):
        return self.__load_config

    def get_env_vars(self):
        return self.__load_config.get("env_vars", {})

    def get_spark_config(self):
        return self.__load_config.get("conf", {})

    def get_py_files(self):
        return self.__load_config.get("py_files", [])

    @property
    def session(self):
        """
        create a Spark Context by SparkSession
            
            return: pyspark.sql.session.SparkSession

        """
        if not isinstance(SparkHook._instance, dict):
            SparkHook._instance = {}
        ins = SparkHook._instance.get('_spark_session')
        if (not ins or not self.is_active):
            # import os global variable
            try:
                for k, v in self.get_env_vars().items():
                    self.syslog.info('SET VARIABLE: %s:%s' % (k, v))
                    os.environ[k] = v
            except BaseException as e:
                self.syslog.info("Cannot import variable spark because:\n%s" % self.syslog.print_traceback())
                pass

            self.syslog.info('[Spark] Create main context ...')

            if self.__auto_find_pyspark:
                import findspark
                self.syslog.info(
                    "[Spark] init SPARK_HOME by findspark with path: %s " % self.__load_config['spark_home'])
                findspark.init()
            ss = SparkSession.builder.appName(self.__app_name)
            conf = SparkConf()
            logger.info("[Spark] set master: %s" % self.__master)
            conf.setMaster(self.__master)
            def_conf = copy.deepcopy(self.get_spark_config())
            if self.__mode:
                def_conf["spark.submit.deployMode"] = self.__mode

            if def_conf:
                for c, v in def_conf.items():
                    self.syslog.info('[Spark] set config: %s: %s' % (c, v))
                    conf = conf.set(c, v)
            if self.__enable_hive_support:
                logger.info("[Spark] enable HiveSupport: true")
                SparkHook._instance['_spark_session'] = ss.config(conf=conf).enableHiveSupport().getOrCreate()
            else:
                SparkHook._instance['_spark_session'] = ss.config(conf=conf).getOrCreate()
            py_file = self.get_py_files()
            if py_file:
                self.syslog.info("[Spark] start add file: %s" % py_file)
                for f in py_file:
                    SparkHook._instance['_spark_session'].sparkContext.addPyFile(f)
            return SparkHook._instance['_spark_session']
        return ins

    @property
    def sc(self):
        """
        get spark context from SparkSession

            return: pyspark.context.SparkHook

        """
        return self.session.sparkContext

    @property
    def is_active(self):
        """
        check spark_context is running or not
        
            return:
        
        """
        try:
            spark = SparkHook._instance.get('_spark_session')
            if spark:
                spark.sparkContext.sparkUser()
                return True
            else:
                self.syslog.info("SparkHook have not been initialized")
        except BaseException as e:
            self.syslog.error("SparkHook is stopped. Error:\n %s" % traceback.format_exc())
        return False

    @property
    def spark_funcs(self):
        return spark_functions

    @property
    def spark_dtypes(self):
        """
        return spark data type

            return: pyspark.sql.types

        """
        return spark_type

    @staticmethod
    def replace_template(text, params):
        """
        replace template params with given param

            text: ex: select * from {table}
            params: ex :{table: 'table_tempƒ'}
            return:

        """
        for k, v in params.items():
            text = text.replace('{%s}' % k, '%s' % v)
        return text

    def run_sql(self, sql, log=True, multi=False, replace_params={}):
        """
        run pyspark sql by sqlContext

            sql:
            return:

        """
        sql = self.replace_template(sql, replace_params)
        if not multi:
            if log:
                self.syslog.info(
                    "Start query sql by sqlContext\n:-----------------------------\n%s\n-----------------------" % sql)
            return self.session.sql(sql)
        for k in sql.split(';'):
            if k.strip():
                if log:
                    self.syslog.info("Run query:\n %s" % k)
                self.session.sql(k)
        return True

    def create_df_by_ldict(self, data):
        """
        create dataframe by list dict

            data: list of dicr
            return: from pyspark.sql import HiveContext

        """
        return self.session.createDataFrame(data)

    def check_table_exist(self, table):
        """
        Check table exists or not

            table:
            return:

        """
        try:
            database = table.split('.')[0]
            table_name = table.split('.')[1]
            rs = self.run_sql("show tables in %s like '%s'" % (database, table_name), False).collect()
            if rs:
                return True
            return False
        except BaseException as e:
            self.syslog.error("Error when check table exists: %s \n trace: " % (table, traceback.format_exc()))
            return False

    def stop(self):
        try:
            self.syslog.info('[Spark] Stop sparkSession, SparkHook and clear instances...')
            # self.session.sc.stop()
            ins = SparkHook._instance.get('_spark_session')
            if ins:
                logger.info("Stop spark context of SparkHook...")
                ins.sparkContext.stop()
                try:
                    logger.info("Stop spark session of SparkHook...")
                    ins.stop()
                except BaseException as e:
                    pass
            SparkHook._instance = {}
            SparkHook._instance.clear()
            self._instance = {}
            return True
        except BaseException as e:
            self.syslog.error("Error when clear spark object: %s \n trace: " % (traceback.format_exc()))
            return False
