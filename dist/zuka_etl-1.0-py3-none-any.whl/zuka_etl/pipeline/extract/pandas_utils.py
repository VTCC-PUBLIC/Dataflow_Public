#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode

from airflow.hooks.base_hook import BaseHook
from zuka_etl.utils import timeit
from zuka_etl.helpers.sql import replace_template
from sqlalchemy import create_engine
from zuka_etl.log import logger
from airflow.hooks.hdfs_hook import HDFSHook
from zuka_etl.setting import Setting
import pandas as pd


class PandasDfFromSQL(object):
    """
       Using SQLAchemy library to get data and import to pandas df
    """

    @staticmethod
    @timeit
    def from_sql(table, connection_id, params={}, **kwargs):
        """
            table: query or table
            connection_id: airflow connection id
            params: replace query with params: 
                select * from {table} - params: {'table':'database.test'}
            kwargs: kwargs for read_sql pandas method
            return:
        
        """
        config = BaseHook.get_connection(connection_id)
        uri = config.get_uri()
        db_connection = create_engine(uri)
        return pd.read_sql(replace_template(table, params), con=db_connection, **kwargs)


class PandasDfFromIter(object):
    """
       Create pandas from iterator
   
    """

    @staticmethod
    def from_iter(iter):
        # TODO: import iterator to pandas
        pass


class PandasDfFromHDFS(object):

    @staticmethod
    def read_from_hdfs(full_file_path, conn_id, engine="hdfs_client", **kwargs):
        """
        reading file from HDFS
        
            full_file_path: path file that will be read
            conn_id: connection defined on airflow
            engine: mode to upload file
                   http: upload via http protocol
                   hdfs_client: upload via local hadoop client
            kwargs:
            return: pandas df
        
        """

        try:
            if conn_id is not None:
                conn = HDFSHook.get_hook(conn_id)
                host = "%s:%s" % (conn.host, conn.port)
                if host == "":
                    raise ValueError("HDFS_HOST is not define. you need to config con airflow or variable")
            else:
                if engine == "http":
                    from hdfs import InsecureClient
                    host = Setting.HDFS_HOST
                    client_hdfs = InsecureClient('http://' + host, **kwargs)
                    with client_hdfs.read(full_file_path, encoding='utf-8') as reader:
                        logger.info("Reading file HDFS throw http, path = %s" % full_file_path)
                        df = pd.read_csv(reader, index_col=0)
                elif engine == "hdfs_client":
                    import pydoop.hdfs as hdfs
                    with hdfs.open(full_file_path) as f:
                        logger.info("Reading file HDFS throw Hadoop Client, path = %s" % full_file_path)
                        df = pd.read_csv(f)
                else:
                    raise ValueError("engine: %s is not supported" % engine)
            return df
        except Exception as ex:
            logger.error(ex)
            logger.exception(ex)
