#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 11/9/18 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# # set enviroment in dev mode

from airflow.contrib.hooks.ftp_hook import FTPHook
from zuka_etl.log import logger
import os
class Ftp(object):

    @staticmethod
    def download_file_from_ftp(remote_path, local_path, file_name, conn_id):
        """
        This function get a file from an FTP, then save it to a folder

            remote_path: path file that will be download from FTP
            local_path: path file that will be store
            file_name: file name
            conn_id: connection id defined on airflow
            return: local_filepath
        
        """
        try:
            conn = FTPHook(ftp_conn_id=conn_id)
            remote_filepath = remote_path + file_name
            local_filepath = local_path + file_name
            if os.path.exists(remote_filepath):
                logger.info('Getting file: {}'.format(remote_filepath))
                conn.store_file(remote_filepath, local_filepath)
                return local_filepath
            else:
                logger.error('Error: File not exists!')
            conn.close_conn()
        except Exception as ex:
            logger.error(ex)
            logger.exception(ex)
