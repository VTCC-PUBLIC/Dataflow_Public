#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'
# !/usr/bin/python
#
# Copyright 2015 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import time
import os
from zuka_etl.setting import Setting as config
from zuka_etl.utils import current_time_utc, debug_tool
import traceback
from zuka_etl.log import logger, logging


class Syslog(object):

    def __init__(self, **kwargs):
        self.log_start = self.get_time_now()

    @staticmethod
    def create_unique_job_id():
        import uuid
        return str(uuid.uuid4())

    @staticmethod
    def mkdir(directory):
        directory = os.path.dirname(directory)
        if not os.path.exists(directory):
            os.makedirs(directory)

    @staticmethod
    def create_path_file_handle_log(file, after_fix=''):
        after_fix = '_' + str(after_fix) if after_fix else ''
        file = file + '_' if file else ''
        log_path = config.LOG_JOB_PATH + file + current_time_utc().strftime(
            '%Y_%m_%d').__str__() + after_fix + '.log'
        return log_path

    @staticmethod
    def set_file_handle_log(file, after_fix='', reset_file=False):
        log_path = Syslog.create_path_file_handle_log(file=file, after_fix=after_fix)
        Syslog.mkdir(log_path)
        if reset_file:
            f = open(log_path, 'w')
            f.close()
        for hdlr in logger.handlers[:]:  # remove all old handlers
            logger.removeHandler(hdlr)

        hdlr = logging.FileHandler(log_path)
        logger.addHandler(hdlr)

        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        formatter.converter = time.gmtime
        hdlr.setFormatter(formatter)
        Syslog.current_file_log = log_path

        return log_path

    @staticmethod
    def set_email_handle_log(**kwargs):
        pass
        return
        subject = kwargs.get('subject', '')
        fromadds = kwargs.get('fromadd', config.MAIL_ERROR_CONFIG['from'])
        smtp_handler = logging.handlers.SMTPHandler(
            mailhost=(config.MAIL_ERROR_CONFIG['mailhost'], config.MAIL_ERROR_CONFIG['port']),
            fromaddr=fromadds,
            toaddrs=config.MAIL_ERROR_CONFIG['to'],
            # credentials=(),
            subject=subject)
        smtp_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(smtp_handler)

    @staticmethod
    def get_time_now():
        return current_time_utc(reset_time=False)

    @staticmethod
    def convert_message(mes):
        if type(mes) is list:
            mes = '\n'.join(mes)
        return str(mes)

    @staticmethod
    def print_log(text, header=""):
        if header:
            header = header + " \n"
        logger.info(header + Syslog.convert_message(text))

    @staticmethod
    def print_error(text, header=""):
        if header:
            header = header + " \n"
        logger.error(header + Syslog.convert_message(text))

    @staticmethod
    def print_traceback():
        return traceback.format_exc()

    @staticmethod
    def debug(text, keep=False):
        debug_tool(text, keep)
