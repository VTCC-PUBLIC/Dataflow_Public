from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
from airflow.models import Variable
from zuka_etl.custom.operator import EtlOperator
from zuka_etl.log import logger

dags = DAG(
    'example_zuka_etl',
    'Testing example zuka etl',
    schedule_interval=None,
    start_date=datetime(2020, 1, 30)
)


def extract():
    # process business
    return [{
        "name": "test",
        "id": 1
    }]


def transform(value):
    logger.info(value)
    return value


def load(value):
    # save data into some data sources
    logger.info("done")


t1 = EtlOperator(task_id="main_job", extract=extract, transform=transform, load=load, dags=dags)
t1
